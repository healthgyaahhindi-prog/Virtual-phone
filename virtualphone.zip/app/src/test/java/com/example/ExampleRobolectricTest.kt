package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.database.VirtualPhoneDatabase
import com.example.data.entity.BrowserAccountEntity
import com.example.data.entity.BrowserHistoryEntity
import com.example.data.entity.GalleryItemEntity
import com.example.data.entity.VirtualNoteEntity
import com.example.data.repository.VirtualPhoneRepository
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var database: VirtualPhoneDatabase
    private lateinit var repository: VirtualPhoneRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, VirtualPhoneDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = VirtualPhoneRepository(database)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `read string from context matches VirtualPhone`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("VirtualPhone", appName)
    }

    @Test
    fun `first launch initializes database and subsequent launch preserves data`() = runBlocking {
        // First launch: should initialize defaults
        val isFirst = repository.initOrRestoreDevice()
        assertTrue("First launch should initialize defaults", isFirst)

        val device = database.virtualDeviceDao().getDeviceDirect()
        assertNotNull("Virtual device should be seeded", device)
        assertTrue(device!!.firstLaunchDone)

        // Add custom browser history & note
        val testUrl = "https://my-custom-test-page.org"
        repository.recordBrowserHistory(testUrl, "Custom Test Page")
        repository.saveNote(0L, "Persistent Note", "Survives app relaunch", "#FEF08A", true)

        // Subsequent launch: should NOT re-seed, preserves existing data
        val isSecondFirst = repository.initOrRestoreDevice()
        assertEquals("Subsequent launch should return false for firstLaunch", false, isSecondFirst)

        val historyCount = database.browserDao().getHistoryCount()
        assertTrue("History count should include added item", historyCount > 0)

        // Run automated persistence verification
        val testResult = repository.runPersistenceTest()
        assertTrue("Persistence test should pass", testResult.passed)
    }

    @Test
    fun `chrome profile persists and does not reset on subsequent launch`() = runBlocking {
        repository.initOrRestoreDevice()

        val profile = database.browserDao().getProfileDirect()
        assertNotNull("Browser profile must exist", profile)
        assertEquals("primary_device", profile!!.deviceId)
        assertEquals(1L, profile.id)
        assertTrue("isFirstRunDone should be true", profile.isFirstRunDone)

        // Add custom history and custom account
        repository.recordBrowserHistory("https://simmail.com/inbox", "SimMail Inbox")
        repository.saveBrowserAccount("simmail.com", "testuser@phone.net", "Test User", "test_tok_123")

        // Simulate subsequent launches / process recreation
        val isSecond = repository.initOrRestoreDevice()
        assertFalse("Subsequent launch is not first launch", isSecond)

        val reloadedProfile = database.browserDao().getProfileDirect()
        assertNotNull("Profile must still exist after restart", reloadedProfile)
        assertEquals("Profile ID must stay 1L", 1L, reloadedProfile!!.id)
        assertTrue("First run must remain done", reloadedProfile.isFirstRunDone)
        assertEquals("https://simmail.com/inbox", reloadedProfile.lastActiveUrl)

        val account = database.browserDao().getAccountForDomain("simmail.com")
        assertNotNull("SimMail session account must persist in Room", account)
        assertEquals("testuser@phone.net", account!!.username)

        // Run dedicated Chrome persistence test
        val chromeTestResult = repository.testChromePersistence()
        assertTrue("Chrome automated persistence test must pass", chromeTestResult.passed)
        assertTrue(chromeTestResult.historyRecordPersisted)
    }

    @Test
    fun `chrome first launch onboarding saves profile and subsequent launches skip onboarding`() = runBlocking {
        repository.initOrRestoreDevice()

        // Complete first-run onboarding with custom account
        repository.completeChromeFirstRun("Sam Morgan", "sam.morgan@virtualphone.net")

        val profile = database.browserDao().getProfileDirect()
        assertNotNull("Browser profile must be saved", profile)
        assertTrue("isFirstRunDone must be true after completing onboarding", profile!!.isFirstRunDone)
        assertEquals("Sam Morgan", profile.profileName)
        assertEquals("sam.morgan@virtualphone.net", profile.email)

        // Record history and tabs
        repository.recordBrowserHistory("https://dailynews.org/tech", "Tech Trends")
        repository.addBrowserTab("Tech Trends", "https://dailynews.org/tech")

        // Simulate app background/stop and restart
        val isSecond = repository.initOrRestoreDevice()
        assertFalse("Subsequent launch is not first launch", isSecond)

        val reloaded = database.browserDao().getProfileDirect()
        assertNotNull("Profile must be restored", reloaded)
        assertTrue("Subsequent launches must have isFirstRunDone = true to skip onboarding", reloaded!!.isFirstRunDone)
        assertEquals("Sam Morgan", reloaded.profileName)
        assertEquals("https://dailynews.org/tech", reloaded.lastActiveUrl)

        val historyCount = database.browserDao().getHistoryCount()
        assertTrue("History records must survive restart", historyCount > 0)
    }

    @Test
    fun `navigation Chrome to Home to Chrome preserves profile setupCompleted and history`() = runBlocking {
        repository.initOrRestoreDevice()

        // User finishes first-run onboarding
        repository.completeChromeFirstRun("Alex Carter", "alex.carter@techstudio.com")

        // User browses and records history
        repository.recordBrowserHistory("https://nexus.search/q/android", "Android Search")
        repository.recordBrowserHistory("https://omnipedia.org/wiki/Kotlin", "Kotlin Wiki")

        // User goes to Home (simulate reading state as Home does)
        val device = database.virtualDeviceDao().getDeviceDirect()
        assertNotNull(device)

        // User re-opens Chrome (re-read directly from Room)
        val reopenedProfile = database.browserDao().getProfileDirect(device!!.id)
        assertNotNull("Reopened profile must exist", reopenedProfile)
        assertTrue("setupCompleted must be true", reopenedProfile!!.setupCompleted)
        assertEquals("Alex Carter", reopenedProfile.profileName)

        val historyCount = database.browserDao().getHistoryCount()
        assertTrue("History count must include browsed items", historyCount >= 2)
    }
}
