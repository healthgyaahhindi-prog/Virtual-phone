package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.ui.VirtualPhoneApp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.VirtualPhoneViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: VirtualPhoneViewModel by viewModels {
        VirtualPhoneViewModel.provideFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    VirtualPhoneApp(viewModel = viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Never clear or reset data on resume! Database state remains pristine.
    }

    override fun onPause() {
        super.onPause()
        // Virtual phone UI may background, persistent data safely in Room DB.
    }

    override fun onStop() {
        super.onStop()
        // Process may be backgrounded or stopped, Room SQLite file remains intact.
    }

    override fun onDestroy() {
        super.onDestroy()
        // Database is NOT deleted. When recreated, existing database is re-opened.
    }
}

