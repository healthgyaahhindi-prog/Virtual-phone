package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.data.entity.VirtualAppEntity
import com.example.ui.apps.browser.BrowserScreen
import com.example.ui.apps.calculator.CalculatorScreen
import com.example.ui.apps.calendar.CalendarScreen
import com.example.ui.apps.camera.CameraScreen
import com.example.ui.apps.clock.ClockScreen
import com.example.ui.apps.contacts.ContactsScreen
import com.example.ui.apps.debug.PersistenceDebugScreen
import com.example.ui.apps.downloads.DownloadsScreen
import com.example.ui.apps.files.FileManagerScreen
import com.example.ui.apps.gallery.GalleryScreen
import com.example.ui.apps.messages.MessagesScreen
import com.example.ui.apps.music.MusicPlayerScreen
import com.example.ui.apps.notes.NotesScreen
import com.example.ui.apps.phone.PhoneScreen
import com.example.ui.apps.settings.SettingsScreen
import com.example.ui.home.AppDrawerScreen
import com.example.ui.home.VirtualHomeScreen
import com.example.ui.system.NotificationShade
import com.example.ui.system.RecentAppsScreen
import com.example.ui.system.VirtualNavigationBar
import com.example.ui.system.VirtualStatusBar
import com.example.ui.system.WallpaperBackground
import com.example.ui.viewmodel.VirtualPhoneViewModel

@Composable
fun VirtualPhoneApp(
    viewModel: VirtualPhoneViewModel,
    modifier: Modifier = Modifier
) {
    val device by viewModel.device.collectAsState()
    val allApps by viewModel.allApps.collectAsState()
    val dockApps by viewModel.dockApps.collectAsState()
    val recentApps by viewModel.recentApps.collectAsState()

    val currentApp by viewModel.currentApp.collectAsState()
    val isRecentAppsOpen by viewModel.isRecentAppsOpen.collectAsState()
    val isNotificationShadeOpen by viewModel.isNotificationShadeOpen.collectAsState()
    val isAppDrawerOpen by viewModel.isAppDrawerOpen.collectAsState()

    val simulatedTime by viewModel.simulatedTime.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    val browserProfile by viewModel.browserProfile.collectAsState()
    val browserHistory by viewModel.browserHistory.collectAsState()
    val browserBookmarks by viewModel.browserBookmarks.collectAsState()
    val browserTabs by viewModel.browserTabs.collectAsState()
    val browserAccounts by viewModel.browserAccounts.collectAsState()

    val galleryItems by viewModel.galleryItems.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val callLogs by viewModel.callLogs.collectAsState()

    val notes by viewModel.notes.collectAsState()
    val calendarEvents by viewModel.calendarEvents.collectAsState()
    val downloads by viewModel.downloads.collectAsState()

    val isTesting by viewModel.isTesting.collectAsState()
    val testResult by viewModel.testResult.collectAsState()

    val isTestingChrome by viewModel.isTestingChrome.collectAsState()
    val chromeTestResult by viewModel.chromeTestResult.collectAsState()

    // Android Hardware Back button integration
    BackHandler(enabled = true) {
        val handled = viewModel.onBackPressed()
        if (!handled) {
            // At root home screen, back does nothing or lets system minimize
        }
    }

    val wallpaperId = device?.wallpaperId ?: 1
    val isDark = device?.isDarkTheme ?: true
    val brightness = device?.brightness ?: 0.85f
    val volume = device?.volumeLevel ?: 0.70f
    val isWifi = device?.isWifiOn ?: true
    val isBluetooth = device?.isBluetoothOn ?: true
    val battery = device?.batteryLevel ?: 88

    WallpaperBackground(wallpaperId = wallpaperId, modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // 1. VIRTUAL STATUS BAR
            VirtualStatusBar(
                timeString = simulatedTime,
                batteryLevel = battery,
                isWifiOn = isWifi,
                notifications = notifications,
                onStatusBarClicked = { viewModel.toggleNotificationShade() }
            )

            // 2. MAIN VIRTUAL SCREEN CONTAINER
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                // If no app is open, show Home Screen
                if (currentApp == null) {
                    VirtualHomeScreen(
                        allApps = allApps,
                        dockApps = dockApps,
                        timeString = simulatedTime,
                        onAppClicked = { app -> viewModel.launchApp(app) },
                        onOpenSearch = {
                            val browserApp = allApps.find { it.packageName == "com.virtual.browser" }
                            if (browserApp != null) viewModel.launchApp(browserApp)
                        },
                        onOpenAppDrawer = { viewModel.toggleAppDrawer() }
                    )
                } else {
                    // Open App Window
                    when (currentApp?.packageName) {
                        "com.virtual.browser" -> BrowserScreen(
                            profile = browserProfile,
                            history = browserHistory,
                            bookmarks = browserBookmarks,
                            tabs = browserTabs,
                            accounts = browserAccounts,
                            onCompleteFirstRun = { name, email -> viewModel.completeChromeFirstRun(name, email) },
                            onRecordHistory = { url, title -> viewModel.recordBrowserHistory(url, title) },
                            onAddBookmark = { title, url -> viewModel.addBookmark(title, url) },
                            onRemoveBookmark = { id -> viewModel.removeBookmark(id) },
                            onClearHistory = { viewModel.clearBrowserHistory() },
                            onAddTab = { title, url -> viewModel.addBrowserTab(title, url) },
                            onCloseTab = { id -> viewModel.closeBrowserTab(id) },
                            onSaveAccount = { d, u, n, t -> viewModel.saveBrowserAccount(d, u, n, t) },
                            onLogoutAccount = { d -> viewModel.logoutBrowserAccount(d) }
                        )

                        "com.virtual.gallery" -> GalleryScreen(
                            items = galleryItems,
                            onAddPhoto = { t, c, s, tag -> viewModel.capturePhoto(t, c, s, tag) },
                            onDeletePhoto = { id -> viewModel.deletePhoto(id) },
                            onToggleFavorite = { id, f -> viewModel.toggleFavoritePhoto(id, f) },
                            onSetAsWallpaper = { wp -> viewModel.setWallpaper(wp) }
                        )

                        "com.virtual.camera" -> CameraScreen(
                            onCapturePhoto = { t, c, s, tag -> viewModel.capturePhoto(t, c, s, tag) },
                            onOpenGallery = { viewModel.launchAppByPackage("com.virtual.gallery") }
                        )

                        "com.virtual.phone" -> PhoneScreen(
                            callLogs = callLogs,
                            contacts = contacts,
                            onLogCall = { num, name, type, dur -> viewModel.logCall(num, name, type, dur) }
                        )

                        "com.virtual.messages" -> MessagesScreen(
                            contacts = contacts,
                            messages = messages,
                            onSendMessage = { cId, name, text -> viewModel.sendMessage(cId, name, text) }
                        )

                        "com.virtual.contacts" -> ContactsScreen(
                            contacts = contacts,
                            onAddContact = { n, p, e, c -> viewModel.addContact(n, p, e, c) },
                            onDeleteContact = { id -> viewModel.deleteContact(id) },
                            onCallContact = { contact ->
                                viewModel.launchAppByPackage("com.virtual.phone")
                            },
                            onMessageContact = { contact ->
                                viewModel.launchAppByPackage("com.virtual.messages")
                            }
                        )

                        "com.virtual.calculator" -> CalculatorScreen()

                        "com.virtual.clock" -> ClockScreen(currentTimeString = simulatedTime)

                        "com.virtual.calendar" -> CalendarScreen(
                            events = calendarEvents,
                            onAddEvent = { t, d, ts, timeStr, col -> viewModel.addCalendarEvent(t, d, ts, timeStr, col) },
                            onDeleteEvent = { id -> viewModel.deleteCalendarEvent(id) }
                        )

                        "com.virtual.notes" -> NotesScreen(
                            notes = notes,
                            onSaveNote = { id, t, c, col, p -> viewModel.saveNote(id, t, c, col, p) },
                            onDeleteNote = { id -> viewModel.deleteNote(id) }
                        )

                        "com.virtual.files" -> FileManagerScreen(
                            galleryCount = galleryItems.size,
                            downloads = downloads
                        )

                        "com.virtual.music" -> MusicPlayerScreen()

                        "com.virtual.downloads" -> DownloadsScreen(
                            downloads = downloads,
                            onSimulateDownload = { fn, sz, tp -> viewModel.addDownload(fn, sz, tp) }
                        )

                        "com.virtual.settings" -> SettingsScreen(
                            device = device,
                            onSetWallpaper = { wp -> viewModel.setWallpaper(wp) },
                            onToggleTheme = { viewModel.toggleTheme() },
                            onUpdateBrightness = { b -> viewModel.updateBrightness(b) },
                            onUpdateVolume = { v -> viewModel.updateVolume(v) },
                            onToggleWifi = { viewModel.toggleWifi() },
                            onToggleBluetooth = { viewModel.toggleBluetooth() },
                            onResetDevice = { viewModel.resetVirtualDevice() }
                        )

                        "com.virtual.debug" -> PersistenceDebugScreen(
                            device = device,
                            browserProfile = browserProfile,
                            installedAppCount = allApps.size,
                            historyCount = browserHistory.size,
                            accountCount = browserAccounts.size,
                            tabCount = browserTabs.size,
                            bookmarkCount = browserBookmarks.size,
                            galleryCount = galleryItems.size,
                            contactsCount = contacts.size,
                            messagesCount = messages.size,
                            notesCount = notes.size,
                            isTesting = isTesting,
                            testResult = testResult,
                            onRunTest = { viewModel.runPersistenceTest() },
                            isTestingChrome = isTestingChrome,
                            chromeTestResult = chromeTestResult,
                            onRunChromeTest = { viewModel.runChromePersistenceTest() }
                        )
                    }
                }

                // 3. OVERLAYS
                // Recent Apps Switcher Overview
                if (isRecentAppsOpen) {
                    RecentAppsScreen(
                        recentApps = recentApps,
                        onSelectApp = { pkg -> viewModel.launchAppByPackage(pkg) },
                        onCloseApp = { pkg -> viewModel.closeRecentApp(pkg) },
                        onClearAll = { viewModel.clearAllRecentApps() }
                    )
                }

                // App Drawer
                AppDrawerScreen(
                    isOpen = isAppDrawerOpen,
                    allApps = allApps,
                    onAppClicked = { app -> viewModel.launchApp(app) },
                    onCloseDrawer = { viewModel.closeAppDrawer() }
                )

                // Notification & Quick Settings Shade
                NotificationShade(
                    isOpen = isNotificationShadeOpen,
                    isWifiOn = isWifi,
                    isBluetoothOn = isBluetooth,
                    isDarkTheme = isDark,
                    brightness = brightness,
                    volume = volume,
                    notifications = notifications,
                    onToggleWifi = { viewModel.toggleWifi() },
                    onToggleBluetooth = { viewModel.toggleBluetooth() },
                    onToggleTheme = { viewModel.toggleTheme() },
                    onBrightnessChanged = { viewModel.updateBrightness(it) },
                    onDismissNotification = { viewModel.dismissNotification(it) },
                    onClearAllNotifications = { viewModel.clearAllNotifications() },
                    onCloseShade = { viewModel.closeNotificationShade() }
                )
            }

            // 4. VIRTUAL NAVIGATION BAR
            VirtualNavigationBar(
                onBack = { viewModel.onBackPressed() },
                onHome = { viewModel.onHomePressed() },
                onRecents = { viewModel.onRecentsPressed() }
            )
        }
    }
}
