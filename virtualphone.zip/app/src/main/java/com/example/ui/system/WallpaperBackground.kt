package com.example.ui.system

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

@Composable
fun WallpaperBackground(
    wallpaperId: Int,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val brush = when (wallpaperId) {
        1 -> Brush.linearGradient(
            colors = listOf(Color(0xFF0F172A), Color(0xFF1E1B4B), Color(0xFF312E81)),
            start = Offset(0f, 0f),
            end = Offset(1000f, 1800f)
        )
        2 -> Brush.verticalGradient(
            colors = listOf(Color(0xFF831843), Color(0xFF500724), Color(0xFF1E1B4B), Color(0xFF0F172A))
        )
        3 -> Brush.linearGradient(
            colors = listOf(Color(0xFF064E3B), Color(0xFF065F46), Color(0xFF042F2E), Color(0xFF022C22)),
            start = Offset(0f, 0f),
            end = Offset(1000f, 1800f)
        )
        4 -> Brush.radialGradient(
            colors = listOf(Color(0xFF1E3A8A), Color(0xFF172554), Color(0xFF090D16)),
            radius = 1200f
        )
        5 -> Brush.linearGradient(
            colors = listOf(Color(0xFF7C2D12), Color(0xFF431407), Color(0xFF18181B)),
            start = Offset(0f, 0f),
            end = Offset(800f, 1600f)
        )
        else -> Brush.verticalGradient(
            colors = listOf(Color(0xFF18181B), Color(0xFF09090B), Color(0xFF000000))
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(brush)
    ) {
        content()
    }
}
