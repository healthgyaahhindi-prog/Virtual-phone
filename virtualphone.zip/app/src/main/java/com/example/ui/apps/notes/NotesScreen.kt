package com.example.ui.apps.notes

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.VirtualNoteEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotesScreen(
    notes: List<VirtualNoteEntity>,
    onSaveNote: (Long, String, String, String, Boolean) -> Unit,
    onDeleteNote: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var editingNote by remember { mutableStateOf<VirtualNoteEntity?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .testTag("notes_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(text = "Notes", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(text = "${notes.size} persistent notes in SQLite Room", color = Color(0xFFEAB308), fontSize = 11.sp)

            Spacer(modifier = Modifier.height(14.dp))

            if (notes.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(text = "No notes saved yet", color = Color.White.copy(alpha = 0.5f))
                }
            } else {
                LazyVerticalStaggeredGrid(
                    columns = StaggeredGridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalItemSpacing = 10.dp
                ) {
                    items(notes, key = { it.id }) { note ->
                        val noteColor = try {
                            Color(android.graphics.Color.parseColor(note.colorHex))
                        } catch (e: Exception) {
                            Color(0xFFFEF08A)
                        }

                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = noteColor),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { editingNote = note }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = note.title,
                                        color = Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        maxLines = 1,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (note.isPinned) {
                                        Icon(
                                            imageVector = Icons.Default.PushPin,
                                            contentDescription = "Pinned",
                                            tint = Color.Black.copy(alpha = 0.7f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = note.content,
                                    color = Color.Black.copy(alpha = 0.85f),
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp,
                                    maxLines = 6
                                )
                            }
                        }
                    }
                }
            }
        }

        // Add Note FAB
        FloatingActionButton(
            onClick = { showCreateDialog = true },
            containerColor = Color(0xFFEAB308),
            contentColor = Color.Black,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_note_button")
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Note")
        }
    }

    // Create / Edit Dialog
    if (showCreateDialog || editingNote != null) {
        val target = editingNote
        var title by remember(target) { mutableStateOf(target?.title ?: "") }
        var content by remember(target) { mutableStateOf(target?.content ?: "") }
        var selectedColor by remember(target) { mutableStateOf(target?.colorHex ?: "#FEF08A") }
        var isPinned by remember(target) { mutableStateOf(target?.isPinned ?: false) }

        val palette = listOf("#FEF08A", "#BAE6FD", "#BBF7D0", "#FBCFE8", "#DDD6FE")

        AlertDialog(
            onDismissRequest = {
                showCreateDialog = false
                editingNote = null
            },
            title = {
                Text(if (target == null) "New Note" else "Edit Note")
            },
            text = {
                Column {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Title") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = content,
                        onValueChange = { content = it },
                        label = { Text("Note Content") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            palette.forEach { cHex ->
                                val c = Color(android.graphics.Color.parseColor(cHex))
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(c)
                                        .clickable { selectedColor = cHex }
                                )
                            }
                        }

                        IconButton(onClick = { isPinned = !isPinned }) {
                            Icon(
                                imageVector = Icons.Default.PushPin,
                                contentDescription = "Pin",
                                tint = if (isPinned) Color(0xFFEAB308) else Color.Gray
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank() || content.isNotBlank()) {
                            onSaveNote(target?.id ?: 0L, title, content, selectedColor, isPinned)
                            showCreateDialog = false
                            editingNote = null
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                Row {
                    if (target != null) {
                        TextButton(onClick = {
                            onDeleteNote(target.id)
                            editingNote = null
                        }) {
                            Text("Delete", color = Color(0xFFEF4444))
                        }
                    }
                    TextButton(onClick = {
                        showCreateDialog = false
                        editingNote = null
                    }) {
                        Text("Cancel")
                    }
                }
            }
        )
    }
}
