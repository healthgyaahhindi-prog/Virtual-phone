package com.example.ui.apps.debug

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.BrowserProfileEntity
import com.example.data.entity.VirtualDeviceEntity
import com.example.data.repository.ChromePersistenceTestResult
import com.example.data.repository.PersistenceTestResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PersistenceDebugScreen(
    device: VirtualDeviceEntity?,
    browserProfile: BrowserProfileEntity?,
    installedAppCount: Int,
    historyCount: Int,
    accountCount: Int,
    tabCount: Int,
    bookmarkCount: Int,
    galleryCount: Int,
    contactsCount: Int,
    messagesCount: Int,
    notesCount: Int,
    isTesting: Boolean,
    testResult: PersistenceTestResult?,
    onRunTest: () -> Unit,
    isTestingChrome: Boolean,
    chromeTestResult: ChromePersistenceTestResult?,
    onRunChromeTest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp)
            .testTag("debug_persistence_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.BugReport, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(text = "Dev & Persistence Diagnostics", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Database Verification & Integrity", color = Color(0xFFEF4444), fontSize = 11.sp)
                }
            }
        }

        // CHROME SIMULATION PERSISTENCE CARD
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = Color(0xFFEA580C))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Chrome Room State", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        }
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFEA580C).copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (browserProfile != null) "PROFILE ACTIVE" else "NOT INITIALIZED",
                                color = if (browserProfile != null) Color(0xFF10B981) else Color(0xFFEF4444),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    DebugRow("Virtual Device ID", device?.id ?: "primary_device")
                    DebugRow("Chrome Profile ID", browserProfile?.id?.toString() ?: "None")
                    DebugRow("Chrome Setup Completed", if (browserProfile?.setupCompleted == true) "TRUE" else "FALSE")
                    DebugRow("Browser History Count", "$historyCount records")
                    DebugRow("Browser Account Count", "$accountCount sessions")
                    DebugRow("Browser Tab Count", "$tabCount tabs")
                    DebugRow("Browser Bookmark Count", "$bookmarkCount bookmarks")
                    DebugRow("Database profile exists", if (browserProfile != null) "TRUE" else "FALSE")
                    DebugRow("Database account exists", if (accountCount > 0) "TRUE" else "FALSE")
                    val chromeDecision = if (browserProfile != null && browserProfile.setupCompleted) "EXISTING PROFILE" else "FIRST LAUNCH"
                    DebugRow("Chrome startup decision", chromeDecision)
                    DebugRow(
                        "Last Chrome database write",
                        if (browserProfile != null && browserProfile.lastWriteTimestamp > 0)
                            dateFormat.format(Date(browserProfile.lastWriteTimestamp))
                        else "N/A"
                    )
                    DebugRow(
                        "Last Chrome database read",
                        if (browserProfile != null && browserProfile.lastReadTimestamp > 0)
                            dateFormat.format(Date(browserProfile.lastReadTimestamp))
                        else "N/A"
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // "Test Chrome Persistence" Button
                    Button(
                        onClick = onRunChromeTest,
                        enabled = !isTestingChrome,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_chrome_persistence_button")
                    ) {
                        if (isTestingChrome) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Testing Chrome Persistence...")
                        } else {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Test Chrome Persistence", fontWeight = FontWeight.Bold)
                        }
                    }

                    chromeTestResult?.let { res ->
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (res.passed) "CHROME PERSISTENCE VERIFIED" else "TEST FAILED",
                                color = if (res.passed) Color(0xFF10B981) else Color(0xFFEF4444),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        DebugRow("Verified Profile ID", "${res.profileId} (Retained)")
                        DebugRow("Test History Record", res.testUrl)
                        DebugRow("History Persisted", if (res.historyRecordPersisted) "TRUE" else "FALSE")
                        DebugRow("Roundtrip Latency", "${res.writeDurationMs + res.readDurationMs} ms")
                    }
                }
            }
        }

        // FULL DATABASE STATUS CARD
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Storage, contentDescription = null, tint = Color(0xFF10B981))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "SQLite Room Status", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        }
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF10B981).copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(text = "CONNECTED", color = Color(0xFF10B981), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    DebugRow("Virtual Device ID", device?.id ?: "primary_device")
                    DebugRow("Device Model", device?.modelName ?: "Pixel Virtual Pro 15")
                    DebugRow("Database Engine", "AndroidX Room (SQLite v2)")
                    DebugRow("First Launch Status", if (device?.firstLaunchDone == true) "Completed (Persistent)" else "Pending")
                    DebugRow("Installed Apps Count", "$installedAppCount apps")
                    DebugRow("Gallery Items Count", "$galleryCount photos")
                    DebugRow("Contacts Count", "$contactsCount entries")
                    DebugRow("Messages Count", "$messagesCount messages")
                    DebugRow("Virtual Notes Count", "$notesCount notes")
                    DebugRow("Last DB Write", device?.let { dateFormat.format(Date(it.lastWriteTime)) } ?: "Just now")
                    DebugRow("Last DB Read", device?.let { dateFormat.format(Date(it.lastReadTime)) } ?: "Just now")
                }
            }
        }

        // RUN SYSTEM-WIDE TEST CARD
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "System-Wide Persistence Verification", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Executes an immediate round-trip write/read assertion on the local SQLite Room database, bypassing any volatile in-memory cache to verify disk persistence.",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onRunTest,
                        enabled = !isTesting,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("run_persistence_test_button")
                    ) {
                        if (isTesting) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Executing Room Assertions...")
                        } else {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Run Full System Persistence Test", fontWeight = FontWeight.Bold)
                        }
                    }

                    testResult?.let { result ->
                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "SYSTEM TEST PASSED: 100% PERSISTENT", color = Color(0xFF10B981), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        DebugRow("Test Token", result.testToken)
                        DebugRow("Write Duration", "${result.writeDurationMs} ms")
                        DebugRow("Read Duration", "${result.readDurationMs} ms")
                        DebugRow("Verified History Count", "${result.historyCount}")
                        DebugRow("Verified Gallery Count", "${result.galleryCount}")
                        DebugRow("Verified Accounts Count", "${result.accountsCount}")
                        DebugRow("Verified Contacts Count", "${result.contactsCount}")
                        DebugRow("Verified Target Device", result.deviceModel)
                        DebugRow("Test Executed", dateFormat.format(Date(result.timestamp)))
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun DebugRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        Text(text = value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
