package com.example.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.database.VirtualPhoneDatabase
import com.example.data.entity.BrowserAccountEntity
import com.example.data.entity.BrowserBookmarkEntity
import com.example.data.entity.BrowserHistoryEntity
import com.example.data.entity.BrowserProfileEntity
import com.example.data.entity.BrowserTabEntity
import com.example.data.entity.CalendarEventEntity
import com.example.data.entity.CallLogEntity
import com.example.data.entity.ContactEntity
import com.example.data.entity.DownloadItemEntity
import com.example.data.entity.GalleryItemEntity
import com.example.data.entity.MessageEntity
import com.example.data.entity.RecentAppEntity
import com.example.data.entity.VirtualAppEntity
import com.example.data.entity.VirtualDeviceEntity
import com.example.data.entity.VirtualNoteEntity
import com.example.data.entity.VirtualNotificationEntity
import com.example.data.repository.PersistenceTestResult
import com.example.data.repository.VirtualPhoneRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VirtualPhoneViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: VirtualPhoneRepository
    val testResult = MutableStateFlow<PersistenceTestResult?>(null)
    val isTesting = MutableStateFlow(false)

    val chromeTestResult = MutableStateFlow<com.example.data.repository.ChromePersistenceTestResult?>(null)
    val isTestingChrome = MutableStateFlow(false)

    val chromeStartupDecision = MutableStateFlow("CHECKING PROFILE...")
    val chromeDecisionReason = MutableStateFlow("Initializing Room profile...")

    // Virtual OS Window & Navigation States
    private val _currentApp = MutableStateFlow<VirtualAppEntity?>(null)
    val currentApp: StateFlow<VirtualAppEntity?> = _currentApp.asStateFlow()

    private val _isRecentAppsOpen = MutableStateFlow(false)
    val isRecentAppsOpen: StateFlow<Boolean> = _isRecentAppsOpen.asStateFlow()

    private val _isNotificationShadeOpen = MutableStateFlow(false)
    val isNotificationShadeOpen: StateFlow<Boolean> = _isNotificationShadeOpen.asStateFlow()

    private val _isAppDrawerOpen = MutableStateFlow(false)
    val isAppDrawerOpen: StateFlow<Boolean> = _isAppDrawerOpen.asStateFlow()

    // Status Bar & System simulation
    val simulatedTime = MutableStateFlow("10:24")

    // Database reactive streams
    val device: StateFlow<VirtualDeviceEntity?>
    val allApps: StateFlow<List<VirtualAppEntity>>
    val dockApps: StateFlow<List<VirtualAppEntity>>
    val recentApps: StateFlow<List<RecentAppEntity>>

    val browserProfile: StateFlow<BrowserProfileEntity?>
    val browserHistory: StateFlow<List<BrowserHistoryEntity>>
    val browserBookmarks: StateFlow<List<BrowserBookmarkEntity>>
    val browserTabs: StateFlow<List<BrowserTabEntity>>
    val browserAccounts: StateFlow<List<BrowserAccountEntity>>

    val galleryItems: StateFlow<List<GalleryItemEntity>>
    val contacts: StateFlow<List<ContactEntity>>
    val messages: StateFlow<List<MessageEntity>>
    val callLogs: StateFlow<List<CallLogEntity>>
    val notifications: StateFlow<List<VirtualNotificationEntity>>

    val notes: StateFlow<List<VirtualNoteEntity>>
    val calendarEvents: StateFlow<List<CalendarEventEntity>>
    val downloads: StateFlow<List<DownloadItemEntity>>

    init {
        val db = VirtualPhoneDatabase.getInstance(application)
        repository = VirtualPhoneRepository(db)

        device = repository.deviceFlow.stateIn(viewModelScope, SharingStarted.Eagerly, null)
        allApps = repository.appsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        dockApps = repository.dockAppsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        recentApps = repository.recentAppsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

        browserProfile = repository.browserProfileFlow.stateIn(viewModelScope, SharingStarted.Eagerly, null)
        browserHistory = repository.browserHistoryFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        browserBookmarks = repository.browserBookmarksFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        browserTabs = repository.browserTabsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        browserAccounts = repository.browserAccountsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

        galleryItems = repository.galleryFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        contacts = repository.contactsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        messages = repository.messagesFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        callLogs = repository.callLogsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        notifications = repository.notificationsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

        notes = repository.notesFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        calendarEvents = repository.eventsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        downloads = repository.downloadsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

        // Ensure database is initialized on first launch without clearing existing data!
        viewModelScope.launch {
            repository.initOrRestoreDevice()
        }
    }

    // System Navigation
    fun onHomePressed() {
        _currentApp.value = null
        _isRecentAppsOpen.value = false
        _isNotificationShadeOpen.value = false
        _isAppDrawerOpen.value = false
    }

    fun onBackPressed(): Boolean {
        if (_isNotificationShadeOpen.value) {
            _isNotificationShadeOpen.value = false
            return true
        }
        if (_isRecentAppsOpen.value) {
            _isRecentAppsOpen.value = false
            return true
        }
        if (_isAppDrawerOpen.value) {
            _isAppDrawerOpen.value = false
            return true
        }
        if (_currentApp.value != null) {
            _currentApp.value = null
            return true
        }
        return false
    }

    fun onRecentsPressed() {
        _isRecentAppsOpen.value = !_isRecentAppsOpen.value
        _isNotificationShadeOpen.value = false
        _isAppDrawerOpen.value = false
    }

    fun toggleNotificationShade() {
        _isNotificationShadeOpen.value = !_isNotificationShadeOpen.value
        _isRecentAppsOpen.value = false
    }

    fun closeNotificationShade() {
        _isNotificationShadeOpen.value = false
    }

    fun toggleAppDrawer() {
        _isAppDrawerOpen.value = !_isAppDrawerOpen.value
        _isRecentAppsOpen.value = false
        _isNotificationShadeOpen.value = false
    }

    fun closeAppDrawer() {
        _isAppDrawerOpen.value = false
    }

    fun launchApp(app: VirtualAppEntity) {
        _currentApp.value = app
        _isRecentAppsOpen.value = false
        _isAppDrawerOpen.value = false
        _isNotificationShadeOpen.value = false

        if (app.packageName == "com.virtual.browser") {
            logChromeStartup()
        }

        viewModelScope.launch {
            repository.openApp(app.packageName, app.appName, app.iconName)
        }
    }

    fun launchAppByPackage(packageName: String) {
        val app = allApps.value.find { it.packageName == packageName }
        if (app != null) {
            launchApp(app)
        }
    }

    fun closeRecentApp(packageName: String) {
        viewModelScope.launch {
            repository.closeRecentApp(packageName)
        }
        if (_currentApp.value?.packageName == packageName) {
            _currentApp.value = null
        }
    }

    fun clearAllRecentApps() {
        viewModelScope.launch {
            repository.clearAllRecentApps()
        }
    }

    // Wallpaper & Customization
    fun setWallpaper(id: Int) {
        viewModelScope.launch {
            repository.updateWallpaper(id)
        }
    }

    fun toggleTheme() {
        val currentDark = device.value?.isDarkTheme ?: true
        viewModelScope.launch {
            repository.updateTheme(!currentDark)
        }
    }

    fun updateBrightness(brightness: Float) {
        val d = device.value ?: return
        viewModelScope.launch {
            repository.updateQuickSettings(d.isWifiOn, d.isBluetoothOn, brightness, d.volumeLevel)
        }
    }

    fun updateVolume(volume: Float) {
        val d = device.value ?: return
        viewModelScope.launch {
            repository.updateQuickSettings(d.isWifiOn, d.isBluetoothOn, d.brightness, volume)
        }
    }

    fun toggleWifi() {
        val d = device.value ?: return
        viewModelScope.launch {
            repository.updateQuickSettings(!d.isWifiOn, d.isBluetoothOn, d.brightness, d.volumeLevel)
        }
    }

    fun toggleBluetooth() {
        val d = device.value ?: return
        viewModelScope.launch {
            repository.updateQuickSettings(d.isWifiOn, !d.isBluetoothOn, d.brightness, d.volumeLevel)
        }
    }

    // Browser Actions
    fun recordBrowserHistory(url: String, title: String) {
        viewModelScope.launch {
            repository.recordBrowserHistory(url, title)
        }
    }

    fun addBookmark(title: String, url: String) {
        viewModelScope.launch {
            repository.addBookmark(title, url)
        }
    }

    fun removeBookmark(id: Long) {
        viewModelScope.launch {
            repository.removeBookmark(id)
        }
    }

    fun clearBrowserHistory() {
        viewModelScope.launch {
            repository.clearBrowserHistory()
        }
    }

    fun addBrowserTab(title: String, url: String) {
        viewModelScope.launch {
            repository.addBrowserTab(title, url)
        }
    }

    fun closeBrowserTab(id: Long) {
        viewModelScope.launch {
            repository.closeBrowserTab(id)
        }
    }

    fun saveBrowserAccount(domain: String, username: String, displayName: String, token: String) {
        viewModelScope.launch {
            repository.saveBrowserAccount(domain, username, displayName, token)
        }
    }

    fun logoutBrowserAccount(domain: String) {
        viewModelScope.launch {
            repository.removeBrowserAccount(domain)
        }
    }

    fun completeChromeFirstRun(name: String, email: String) {
        viewModelScope.launch {
            repository.completeChromeFirstRun(name, email)
            logChromeStartup()
        }
    }

    fun logChromeStartup() {
        viewModelScope.launch {
            val profile = repository.getBrowserProfileDirect() ?: browserProfile.value
            val historyCount = repository.getBrowserHistoryCount()
            val accountCount = repository.getBrowserAccountsCount()
            val deviceId = profile?.deviceId ?: (device.value?.id ?: "primary_device")
            val profileId = profile?.id ?: -1L
            val setupCompleted = profile?.setupCompleted ?: false

            val decision = if (profile != null && setupCompleted) "EXISTING PROFILE" else "FIRST LAUNCH"
            val reason = when {
                profile == null -> "No browser profile exists in database for device"
                !setupCompleted -> "Browser profile exists (id=${profile.id}, deviceId=${profile.deviceId}) but setupCompleted=false"
                else -> "Persistent browser profile found in Room (id=${profile.id}, deviceId=${profile.deviceId}) with setupCompleted=true"
            }

            chromeStartupDecision.value = decision
            chromeDecisionReason.value = reason

            Log.d("CHROME_START", "deviceId=$deviceId profileId=$profileId setupCompleted=$setupCompleted historyCount=$historyCount accountCount=$accountCount")
            Log.d("CHROME_ONBOARDING_DECISION", "reason=$reason (decision=$decision)")
        }
    }

    fun runChromePersistenceTest() {
        viewModelScope.launch {
            isTestingChrome.value = true
            val res = repository.testChromePersistence()
            chromeTestResult.value = res
            isTestingChrome.value = false
        }
    }

    // Camera & Gallery
    fun capturePhoto(title: String, category: String, colorSeed: String, imageTag: String) {
        viewModelScope.launch {
            repository.addGalleryPhoto(title, category, colorSeed, imageTag)
        }
    }

    fun deletePhoto(id: Long) {
        viewModelScope.launch {
            repository.deleteGalleryItem(id)
        }
    }

    fun toggleFavoritePhoto(id: Long, isFav: Boolean) {
        viewModelScope.launch {
            repository.toggleGalleryFavorite(id, isFav)
        }
    }

    // Communications
    fun addContact(name: String, phone: String, email: String, color: String) {
        viewModelScope.launch {
            repository.addContact(name, phone, email, color)
        }
    }

    fun deleteContact(id: Long) {
        viewModelScope.launch {
            repository.deleteContact(id)
        }
    }

    fun sendMessage(contactId: Long, senderName: String, text: String) {
        viewModelScope.launch {
            // Insert user's message
            repository.sendMessage(contactId, senderName, text, isFromMe = true)
            // Simulated contact reply after short delay
            kotlinx.coroutines.delay(1200)
            val replyText = generateSimulatedReply(text)
            repository.sendMessage(contactId, senderName, replyText, isFromMe = false)
        }
    }

    private fun generateSimulatedReply(input: String): String {
        val lower = input.lowercase()
        return when {
            lower.contains("hello") || lower.contains("hi") -> "Hey there! How is everything going?"
            lower.contains("where") -> "I'm around downtown right now, finishing up some work!"
            lower.contains("when") || lower.contains("time") -> "Let's plan for 4:00 PM!"
            lower.contains("virtual") || lower.contains("phone") -> "The virtual Android phone persistence is working amazingly well!"
            lower.contains("thanks") || lower.contains("thank") -> "You're very welcome!"
            else -> "Sounds great! Let's stay in touch."
        }
    }

    fun logCall(number: String, name: String, type: String, duration: Int) {
        viewModelScope.launch {
            repository.logCall(number, name, type, duration)
        }
    }

    fun dismissNotification(id: Long) {
        viewModelScope.launch {
            repository.dismissNotification(id)
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            repository.clearAllNotifications()
        }
    }

    // Notes
    fun saveNote(id: Long, title: String, content: String, colorHex: String, isPinned: Boolean) {
        viewModelScope.launch {
            repository.saveNote(id, title, content, colorHex, isPinned)
        }
    }

    fun deleteNote(id: Long) {
        viewModelScope.launch {
            repository.deleteNote(id)
        }
    }

    // Calendar
    fun addCalendarEvent(title: String, desc: String, timestamp: Long, timeStr: String, color: String) {
        viewModelScope.launch {
            repository.addCalendarEvent(title, desc, timestamp, timeStr, color)
        }
    }

    fun deleteCalendarEvent(id: Long) {
        viewModelScope.launch {
            repository.deleteCalendarEvent(id)
        }
    }

    // Downloads
    fun addDownload(fileName: String, size: String, type: String) {
        viewModelScope.launch {
            repository.addDownload(fileName, size, type)
        }
    }

    // RESET VIRTUAL DEVICE (ONLY through explicit user request in Settings)
    fun resetVirtualDevice() {
        viewModelScope.launch {
            repository.resetVirtualDevice()
            _currentApp.value = null
            _isRecentAppsOpen.value = false
            _isNotificationShadeOpen.value = false
            _isAppDrawerOpen.value = false
        }
    }

    // RUN PERSISTENCE TEST
    fun runPersistenceTest() {
        viewModelScope.launch {
            isTesting.value = true
            val res = repository.runPersistenceTest()
            testResult.value = res
            isTesting.value = false
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return VirtualPhoneViewModel(application) as T
                }
            }
    }
}
