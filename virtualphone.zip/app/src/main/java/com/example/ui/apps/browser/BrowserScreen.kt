package com.example.ui.apps.browser

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.BrowserAccountEntity
import com.example.data.entity.BrowserBookmarkEntity
import com.example.data.entity.BrowserHistoryEntity
import com.example.data.entity.BrowserProfileEntity
import com.example.data.entity.BrowserTabEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BrowserScreen(
    profile: BrowserProfileEntity?,
    history: List<BrowserHistoryEntity>,
    bookmarks: List<BrowserBookmarkEntity>,
    tabs: List<BrowserTabEntity>,
    accounts: List<BrowserAccountEntity>,
    onCompleteFirstRun: (String, String) -> Unit,
    onRecordHistory: (String, String) -> Unit,
    onAddBookmark: (String, String) -> Unit,
    onRemoveBookmark: (Long) -> Unit,
    onClearHistory: () -> Unit,
    onAddTab: (String, String) -> Unit,
    onCloseTab: (Long) -> Unit,
    onSaveAccount: (String, String, String, String) -> Unit,
    onLogoutAccount: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showChromeDebugDialog by remember { mutableStateOf(false) }

    // Log Chrome startup and onboarding decision
    val startupDecision = if (profile != null && profile.setupCompleted) "EXISTING PROFILE" else "FIRST LAUNCH"
    val decisionReason = when {
        profile == null -> "Database profile is null / loading from Room disk"
        !profile.setupCompleted -> "Profile exists in Room (id=${profile.id}, deviceId=${profile.deviceId}) but setupCompleted=false"
        else -> "Persistent profile exists in Room (id=${profile.id}, deviceId=${profile.deviceId}) with setupCompleted=true"
    }

    LaunchedEffect(profile?.id, profile?.setupCompleted) {
        Log.d(
            "CHROME_START",
            "deviceId=${profile?.deviceId ?: "primary_device"} profileId=${profile?.id ?: -1L} setupCompleted=${profile?.setupCompleted ?: false} historyCount=${history.size} accountCount=${accounts.size}"
        )
        Log.d(
            "CHROME_ONBOARDING_DECISION",
            "reason=$decisionReason"
        )
    }

    // 1. If profile is null, Room is still reading from SQLite: Show clean Chrome loading state
    if (profile == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A))
                .testTag("browser_loading_screen"),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFEA580C)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Chrome",
                        tint = Color.White,
                        modifier = Modifier.size(42.dp)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                CircularProgressIndicator(
                    color = Color(0xFFEA580C),
                    modifier = Modifier.size(32.dp),
                    strokeWidth = 3.dp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Loading Chrome Profile...",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 14.sp
                )
            }
        }
        return
    }

    // 2. FIRST-LAUNCH RULE:
    // Chrome onboarding must appear ONLY ONCE for a newly created virtual device.
    // If persistent Chrome profile has setupCompleted == true, NEVER show first-launch screen again!
    if (!profile.setupCompleted) {
        MakeChromeYourOwnScreen(
            initialName = profile.profileName.ifEmpty { "Alex Carter" },
            initialEmail = profile.email.ifEmpty { "alex.carter@techstudio.com" },
            onContinue = { name, email -> onCompleteFirstRun(name, email) },
            onOpenDebug = { showChromeDebugDialog = true },
            modifier = modifier
        )
        if (showChromeDebugDialog) {
            ChromeDebugDialog(
                profile = profile,
                historyCount = history.size,
                accountCount = accounts.size,
                tabCount = tabs.size,
                onDismiss = { showChromeDebugDialog = false }
            )
        }
        return
    }

    // MAIN BROWSER UI (RESTORED DIRECTLY FROM PERSISTENT ROOM STATE)
    val initialUrl = profile.lastActiveUrl.ifEmpty { "https://nexus.search" }
    val initialTitle = profile.lastActiveTitle.ifEmpty { "Nexus Search" }

    var currentUrl by remember(profile.lastActiveUrl) { mutableStateOf(initialUrl) }
    var urlInput by remember(profile.lastActiveUrl) { mutableStateOf(initialUrl) }
    var currentTitle by remember(profile.lastActiveTitle) { mutableStateOf(initialTitle) }

    val backStack = remember(profile.lastActiveUrl) { mutableStateListOf(initialUrl) }
    val forwardStack = remember(profile.lastActiveUrl) { mutableStateListOf<String>() }

    var showMenu by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }
    var showBookmarksDialog by remember { mutableStateOf(false) }
    var showTabsDialog by remember { mutableStateOf(false) }

    val simMailAccount = accounts.find { it.siteDomain == "simmail.com" }
    val isCurrentBookmarked = bookmarks.any { it.url == currentUrl }

    fun navigateTo(url: String, title: String) {
        val formatted = if (!url.startsWith("http://") && !url.startsWith("https://")) {
            if (url.contains(".")) "https://$url" else "https://nexus.search/q/${url.replace(" ", "+")}"
        } else url

        backStack.add(formatted)
        forwardStack.clear()
        currentUrl = formatted
        urlInput = formatted
        currentTitle = title
        // Persist immediately to Room database!
        onRecordHistory(formatted, title)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .testTag("browser_screen")
    ) {
        // TOP BROWSER APP BAR
        Card(
            shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Back
                    IconButton(
                        onClick = {
                            if (backStack.size > 1) {
                                val current = backStack.removeAt(backStack.size - 1)
                                forwardStack.add(current)
                                val previous = backStack.last()
                                currentUrl = previous
                                urlInput = previous
                            }
                        },
                        enabled = backStack.size > 1,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Browser Back",
                            tint = if (backStack.size > 1) Color.White else Color.White.copy(alpha = 0.3f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Forward
                    IconButton(
                        onClick = {
                            if (forwardStack.isNotEmpty()) {
                                val next = forwardStack.removeAt(forwardStack.size - 1)
                                backStack.add(next)
                                currentUrl = next
                                urlInput = next
                            }
                        },
                        enabled = forwardStack.isNotEmpty(),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Browser Forward",
                            tint = if (forwardStack.isNotEmpty()) Color.White else Color.White.copy(alpha = 0.3f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Refresh
                    IconButton(
                        onClick = {
                            onRecordHistory(currentUrl, currentTitle)
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Address Bar
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        singleLine = true,
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "SSL Secured",
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(14.dp)
                            )
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = {
                            navigateTo(urlInput, "Web Page")
                        }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF6366F1),
                            unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("browser_address_bar")
                    )

                    Spacer(modifier = Modifier.width(4.dp))

                    // Tabs count badge
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White.copy(alpha = 0.15f))
                            .clickable { showTabsDialog = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${tabs.size.coerceAtLeast(1)}",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Bookmark star
                    IconButton(
                        onClick = {
                            if (isCurrentBookmarked) {
                                val bm = bookmarks.find { it.url == currentUrl }
                                if (bm != null) onRemoveBookmark(bm.id)
                            } else {
                                onAddBookmark(currentTitle, currentUrl)
                            }
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isCurrentBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (isCurrentBookmarked) Color(0xFFFBBF24) else Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // More Menu
                    Box {
                        IconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "More Menu",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("New Tab") },
                                onClick = {
                                    showMenu = false
                                    onAddTab("Nexus Search", "https://nexus.search")
                                    navigateTo("https://nexus.search", "Nexus Search")
                                },
                                leadingIcon = { Icon(Icons.Default.Add, null) }
                            )
                            DropdownMenuItem(
                                text = { Text("History (${history.size})") },
                                onClick = {
                                    showMenu = false
                                    showHistoryDialog = true
                                },
                                leadingIcon = { Icon(Icons.Default.History, null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Bookmarks (${bookmarks.size})") },
                                onClick = {
                                    showMenu = false
                                    showBookmarksDialog = true
                                },
                                leadingIcon = { Icon(Icons.Default.Bookmark, null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Nexus Search Home") },
                                onClick = {
                                    showMenu = false
                                    navigateTo("https://nexus.search", "Nexus Search")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Chrome Debug") },
                                onClick = {
                                    showMenu = false
                                    showChromeDebugDialog = true
                                },
                                leadingIcon = { Icon(Icons.Default.BugReport, null) }
                            )
                        }
                    }
                }
            }
        }

        // BROWSER WEBPAGE DISPLAY
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            RenderSimulatedWebPage(
                url = currentUrl,
                account = simMailAccount,
                onNavigate = { url, title -> navigateTo(url, title) },
                onLoginSimMail = { email, name ->
                    onSaveAccount("simmail.com", email, name, "tok_simmail_${System.currentTimeMillis()}")
                },
                onLogoutSimMail = {
                    onLogoutAccount("simmail.com")
                }
            )
        }
    }

    if (showChromeDebugDialog) {
        ChromeDebugDialog(
            profile = profile,
            historyCount = history.size,
            accountCount = accounts.size,
            tabCount = tabs.size,
            onDismiss = { showChromeDebugDialog = false }
        )
    }

    // DIALOGS: HISTORY, BOOKMARKS, TABS
    if (showHistoryDialog) {
        val dateFormat = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
        AlertDialog(
            onDismissRequest = { showHistoryDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Browsing History", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (history.isNotEmpty()) {
                        TextButton(onClick = onClearHistory) {
                            Text("Clear all", color = Color(0xFFEF4444), fontSize = 12.sp)
                        }
                    }
                }
            },
            text = {
                if (history.isEmpty()) {
                    Text("No browsing history yet.")
                } else {
                    LazyColumn(modifier = Modifier.height(300.dp)) {
                        items(history, key = { it.id }) { item ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showHistoryDialog = false
                                        navigateTo(item.url, item.title)
                                    }
                                    .padding(vertical = 6.dp)
                            ) {
                                Text(item.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(item.url, color = Color(0xFF6366F1), fontSize = 11.sp)
                                Text(dateFormat.format(Date(item.visitedTimestamp)), color = Color.Gray, fontSize = 10.sp)
                                HorizontalDivider(modifier = Modifier.padding(top = 4.dp), color = Color.Gray.copy(alpha = 0.2f))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistoryDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showBookmarksDialog) {
        AlertDialog(
            onDismissRequest = { showBookmarksDialog = false },
            title = { Text("Bookmarks", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                if (bookmarks.isEmpty()) {
                    Text("No bookmarks saved yet.")
                } else {
                    LazyColumn(modifier = Modifier.height(260.dp)) {
                        items(bookmarks, key = { it.id }) { bm ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showBookmarksDialog = false
                                        navigateTo(bm.url, bm.title)
                                    }
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(bm.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(bm.url, color = Color(0xFF6366F1), fontSize = 11.sp)
                                }
                                IconButton(onClick = { onRemoveBookmark(bm.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBookmarksDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showTabsDialog) {
        AlertDialog(
            onDismissRequest = { showTabsDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Open Tabs", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    IconButton(onClick = {
                        onAddTab("New Tab", "https://nexus.search")
                        navigateTo("https://nexus.search", "Nexus Search")
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "New Tab", tint = Color(0xFF6366F1))
                    }
                }
            },
            text = {
                LazyColumn(modifier = Modifier.height(240.dp)) {
                    items(tabs, key = { it.id }) { tab ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (tab.url == currentUrl) Color(0xFF6366F1).copy(alpha = 0.2f) else Color(0xFF1E293B)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    showTabsDialog = false
                                    navigateTo(tab.url, tab.title)
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(tab.title, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    Text(tab.url, color = Color.Gray, fontSize = 10.sp)
                                }
                                if (tabs.size > 1) {
                                    IconButton(
                                        onClick = { onCloseTab(tab.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "Close Tab", tint = Color.Gray, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTabsDialog = false }) {
                    Text("Done")
                }
            }
        )
    }
}

// "MAKE CHROME YOUR OWN" FIRST-RUN EXPERIENCE COMPOSABLE
@Composable
fun MakeChromeYourOwnScreen(
    initialName: String,
    initialEmail: String,
    onContinue: (String, String) -> Unit,
    onOpenDebug: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedName by remember { mutableStateOf(initialName) }
    var selectedEmail by remember { mutableStateOf(initialEmail) }
    var showAddAccountDialog by remember { mutableStateOf(false) }

    var newAccountName by remember { mutableStateOf("") }
    var newAccountEmail by remember { mutableStateOf("") }

    if (showAddAccountDialog) {
        AlertDialog(
            onDismissRequest = { showAddAccountDialog = false },
            title = {
                Text(
                    text = "Add account to device",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Enter account credentials to link with this simulated smartphone:",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = newAccountName,
                        onValueChange = { newAccountName = it },
                        label = { Text("Display Name", color = Color.White.copy(alpha = 0.6f)) },
                        placeholder = { Text("e.g. Jordan Smith") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF6366F1),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_account_name_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newAccountEmail,
                        onValueChange = { newAccountEmail = it },
                        label = { Text("Email Address", color = Color.White.copy(alpha = 0.6f)) },
                        placeholder = { Text("e.g. jordan.smith@virtualphone.net") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF6366F1),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_account_email_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newAccountName.isNotBlank() && newAccountEmail.isNotBlank()) {
                            selectedName = newAccountName.trim()
                            selectedEmail = newAccountEmail.trim()
                            showAddAccountDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                    modifier = Modifier.testTag("confirm_add_account_button")
                ) {
                    Text("Add Account")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddAccountDialog = false }) {
                    Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp)
            .testTag("make_chrome_your_own_screen"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top row with Chrome Debug trigger
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(
                onClick = onOpenDebug,
                colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFEF4444)),
                modifier = Modifier.testTag("chrome_debug_button")
            ) {
                Icon(Icons.Default.BugReport, contentDescription = "Debug", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Chrome Debug", fontSize = 12.sp)
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 10.dp)
        ) {
            // Chrome Logo
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFEA580C)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "Chrome",
                    tint = Color.White,
                    modifier = Modifier.size(42.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Make Chrome your own",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "To get your bookmarks, history, passwords and other settings on all your simulated devices, sign in with your account.",
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Account selection card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF6366F1)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = selectedName.take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = selectedName,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = selectedEmail,
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 12.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Selected",
                        tint = Color(0xFF10B981)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // "Add account to device" Action
            OutlinedButton(
                onClick = { showAddAccountDialog = true },
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF38BDF8)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("add_account_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add account",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Add account to device",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = null,
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Sync is turned on • Data saved persistently in Room DB",
                    fontSize = 11.sp,
                    color = Color(0xFF38BDF8)
                )
            }
        }

        // Action Buttons
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(
                onClick = { onContinue(selectedName, selectedEmail) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("continue_as_account_button")
            ) {
                Text(
                    text = "Continue as $selectedName",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = { onContinue("Guest User", "guest@virtualphone.net") },
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("use_without_account_button")
            ) {
                Text(
                    text = "Use without an account",
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "By continuing, your profile state is stored in local SQLite.",
                fontSize = 10.sp,
                color = Color.White.copy(alpha = 0.5f),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun ChromeDebugDialog(
    profile: BrowserProfileEntity?,
    historyCount: Int,
    accountCount: Int,
    tabCount: Int,
    onDismiss: () -> Unit
) {
    val startupDecision = if (profile != null && profile.setupCompleted) "EXISTING PROFILE" else "FIRST LAUNCH"
    val decisionReason = when {
        profile == null -> "No profile in database / profile loading"
        !profile.setupCompleted -> "profile.setupCompleted is false"
        else -> "Persistent profile exists with setupCompleted=true"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.BugReport, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Chrome Debug", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ChromeDebugRow("Virtual Device ID:", profile?.deviceId ?: "primary_device")
                ChromeDebugRow("Chrome Profile ID:", profile?.id?.toString() ?: "None")
                ChromeDebugRow("Chrome Setup Completed:", if (profile?.setupCompleted == true) "TRUE" else "FALSE")
                ChromeDebugRow("Browser History Count:", "$historyCount")
                ChromeDebugRow("Browser Account Count:", "$accountCount")
                ChromeDebugRow("Browser Tab Count:", "$tabCount")
                HorizontalDivider(color = Color.White.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 4.dp))
                ChromeDebugRow("Database profile exists:", if (profile != null) "TRUE" else "FALSE")
                ChromeDebugRow("Database account exists:", if (accountCount > 0) "TRUE" else "FALSE")
                HorizontalDivider(color = Color.White.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 4.dp))
                Text(
                    text = "Chrome startup decision:",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.7f),
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = startupDecision,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (startupDecision == "EXISTING PROFILE") Color(0xFF10B981) else Color(0xFFF59E0B)
                )
                Text(
                    text = "Reason: $decisionReason",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
            ) {
                Text("Close")
            }
        },
        containerColor = Color(0xFF1E293B)
    )
}

@Composable
fun ChromeDebugRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
        Text(text = value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
