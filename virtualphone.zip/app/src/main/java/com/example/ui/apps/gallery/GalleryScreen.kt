package com.example.ui.apps.gallery

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.GalleryItemEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun GalleryScreen(
    items: List<GalleryItemEntity>,
    onAddPhoto: (String, String, String, String) -> Unit,
    onDeletePhoto: (Long) -> Unit,
    onToggleFavorite: (Long, Boolean) -> Unit,
    onSetAsWallpaper: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategoryIndex by remember { mutableIntStateOf(0) }
    val categories = listOf("All", "Camera", "Wallpapers", "Downloads", "Favorites")

    var selectedItemForDetail by remember { mutableStateOf<GalleryItemEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val filtered = items.filter { item ->
        when (selectedCategoryIndex) {
            0 -> true
            1 -> item.category == "Camera"
            2 -> item.category == "Wallpapers"
            3 -> item.category == "Downloads"
            4 -> item.isFavorite
            else -> true
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .testTag("gallery_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Gallery", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(text = "${items.size} persistent photos in SQLite", color = Color(0xFF10B981), fontSize = 11.sp)
                }
            }

            // Categories
            ScrollableTabRow(
                selectedTabIndex = selectedCategoryIndex,
                containerColor = Color.Transparent,
                contentColor = Color.White,
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedCategoryIndex]),
                        color = Color(0xFFEC4899)
                    )
                }
            ) {
                categories.forEachIndexed { index, cat ->
                    Tab(
                        selected = selectedCategoryIndex == index,
                        onClick = { selectedCategoryIndex = index },
                        text = {
                            Text(
                                text = cat,
                                fontSize = 13.sp,
                                fontWeight = if (selectedCategoryIndex == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Grid
            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(text = "No photos in this album", color = Color.White.copy(alpha = 0.5f), fontSize = 14.sp)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filtered, key = { it.id }) { photo ->
                        GalleryThumbnail(
                            photo = photo,
                            onClick = { selectedItemForDetail = photo }
                        )
                    }
                }
            }
        }

        // Add Photo FAB
        FloatingActionButton(
            onClick = { showAddDialog = true },
            containerColor = Color(0xFFEC4899),
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_photo_button")
        ) {
            Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Add Photo")
        }
    }

    // Photo Detail Dialog
    selectedItemForDetail?.let { photo ->
        val dateFormat = SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault())
        AlertDialog(
            onDismissRequest = { selectedItemForDetail = null },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(photo.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
                    IconButton(onClick = {
                        onToggleFavorite(photo.id, !photo.isFavorite)
                        selectedItemForDetail = photo.copy(isFavorite = !photo.isFavorite)
                    }) {
                        Icon(
                            imageVector = if (photo.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = Color(0xFFEC4899)
                        )
                    }
                }
            },
            text = {
                Column {
                    // Photo Preview Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color(android.graphics.Color.parseColor(photo.colorSeedHex)),
                                        Color(0xFF0F172A)
                                    ),
                                    start = Offset(0f, 0f),
                                    end = Offset(400f, 400f)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "[${photo.category} Preview]",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Category: ${photo.category}", fontSize = 12.sp, color = Color.Gray)
                    Text(text = "Captured: ${dateFormat.format(Date(photo.dateAdded))}", fontSize = 12.sp, color = Color.Gray)
                    Text(text = "Stored persistently in SQLite Room", fontSize = 11.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Medium)

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Button(
                            onClick = {
                                onSetAsWallpaper(1)
                                selectedItemForDetail = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Wallpaper, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Set Wallpaper", fontSize = 12.sp)
                        }

                        IconButton(onClick = {
                            onDeletePhoto(photo.id)
                            selectedItemForDetail = null
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedItemForDetail = null }) {
                    Text("Close")
                }
            }
        )
    }

    // Add Photo Dialog
    if (showAddDialog) {
        var titleInput by remember { mutableStateOf("Sunset Snap") }
        var categoryInput by remember { mutableStateOf("Wallpapers") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Import / Add Photo") },
            text = {
                Column {
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("Photo Title") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = categoryInput,
                        onValueChange = { categoryInput = it },
                        label = { Text("Album Category (e.g. Wallpapers, Camera)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (titleInput.isNotBlank()) {
                            val seedColors = listOf("#3B82F6", "#EC4899", "#8B5CF6", "#10B981", "#F59E0B", "#06B6D4")
                            val pickedColor = seedColors.random()
                            onAddPhoto(titleInput, categoryInput, pickedColor, "landscape")
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Add to Database")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun GalleryThumbnail(
    photo: GalleryItemEntity,
    onClick: () -> Unit
) {
    val seedColor = try {
        Color(android.graphics.Color.parseColor(photo.colorSeedHex))
    } catch (e: Exception) {
        Color(0xFF3B82F6)
    }

    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        modifier = Modifier
            .aspectRatio(1f)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(seedColor, Color(0xFF0F172A)),
                        radius = 250f
                    )
                )
                .padding(6.dp)
        ) {
            if (photo.isFavorite) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = "Favorite",
                    tint = Color(0xFFEC4899),
                    modifier = Modifier
                        .size(16.dp)
                        .align(Alignment.TopEnd)
                )
            }
            Text(
                text = photo.title,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                modifier = Modifier.align(Alignment.BottomStart)
            )
        }
    }
}
