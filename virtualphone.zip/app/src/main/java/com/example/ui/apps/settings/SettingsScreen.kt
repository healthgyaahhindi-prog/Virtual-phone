package com.example.ui.apps.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.VirtualDeviceEntity

@Composable
fun SettingsScreen(
    device: VirtualDeviceEntity?,
    onSetWallpaper: (Int) -> Unit,
    onToggleTheme: () -> Unit,
    onUpdateBrightness: (Float) -> Unit,
    onUpdateVolume: (Float) -> Unit,
    onToggleWifi: () -> Unit,
    onToggleBluetooth: () -> Unit,
    onResetDevice: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showResetConfirmation by remember { mutableStateOf(false) }

    val currentWallpaper = device?.wallpaperId ?: 1
    val isDark = device?.isDarkTheme ?: true
    val brightness = device?.brightness ?: 0.85f
    val volume = device?.volumeLevel ?: 0.70f
    val isWifi = device?.isWifiOn ?: true
    val isBluetooth = device?.isBluetoothOn ?: true

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp)
            .testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(text = "Settings", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(text = "Virtual Device Configuration", color = Color(0xFF64748B), fontSize = 12.sp)
        }

        // WALLPAPER SELECTION
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Wallpaper, contentDescription = null, tint = Color(0xFF6366F1))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Wallpaper Style", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    }
                    Text(text = "Select virtual background (saved persistently)", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)

                    Spacer(modifier = Modifier.height(14.dp))

                    val wallpapers = listOf(
                        1 to Color(0xFF312E81),
                        2 to Color(0xFF831843),
                        3 to Color(0xFF065F46),
                        4 to Color(0xFF1E3A8A),
                        5 to Color(0xFF7C2D12),
                        6 to Color(0xFF18181B)
                    )

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(wallpapers.size) { i ->
                            val (wpId, color) = wallpapers[i]
                            val isSelected = wpId == currentWallpaper

                            Box(
                                modifier = Modifier
                                    .size(54.dp, 80.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(color)
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) Color(0xFF38BDF8) else Color.White.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable { onSetWallpaper(wpId) }
                                    .testTag("wallpaper_option_$wpId"),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = "Selected", tint = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }

        // DISPLAY & SOUND
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Display & Audio", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)

                    Spacer(modifier = Modifier.height(12.dp))

                    // Dark Theme Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = Color(0xFF38BDF8))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(text = "Dark Theme", color = Color.White, fontSize = 13.sp)
                        }
                        Switch(
                            checked = isDark,
                            onCheckedChange = { onToggleTheme() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF38BDF8))
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Brightness Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.BrightnessHigh, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Slider(
                            value = brightness,
                            onValueChange = onUpdateBrightness,
                            valueRange = 0.1f..1.0f,
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color(0xFFFBBF24)),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Volume Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF6366F1), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Slider(
                            value = volume,
                            onValueChange = onUpdateVolume,
                            valueRange = 0.0f..1.0f,
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color(0xFF6366F1)),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // CONNECTIVITY
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Network & Connectivity", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Wifi, contentDescription = null, tint = Color(0xFF10B981))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(text = "Wi-Fi Simulation", color = Color.White, fontSize = 13.sp)
                        }
                        Switch(checked = isWifi, onCheckedChange = { onToggleWifi() })
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bluetooth, contentDescription = null, tint = Color(0xFF3B82F6))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(text = "Bluetooth", color = Color.White, fontSize = 13.sp)
                        }
                        Switch(checked = isBluetooth, onCheckedChange = { onToggleBluetooth() })
                    }
                }
            }
        }

        // ABOUT VIRTUAL DEVICE
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF38BDF8))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "About Virtual Phone", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Model: ${device?.modelName ?: "Pixel Virtual Pro 15"}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text(text = "OS Version: ${device?.osVersion ?: "AVOS 15.2 (Jetpack Compose)"}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text(text = "Database: SQLite Room v1 (Offline Persistent)", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Text(text = "Architecture: Native Android Coroutines + Flow", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text(text = "One-Hour Bug Protection: Inactivity timeouts disabled; data never deleted", color = Color(0xFFFBBF24), fontSize = 11.sp)
                }
            }
        }

        // DATA RESET SECTION (CRITICAL: EXPLICIT USER ACTION ONLY)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF450A0A)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = "Warning", tint = Color(0xFFEF4444))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Factory Reset", color = Color(0xFFFCA5A5), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Resetting the virtual device clears all local tables and restores initial factory defaults. Normal app exit, backgrounding, and phone restart NEVER erase your data.",
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = { showResetConfirmation = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reset_virtual_device_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reset Virtual Device", fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Confirmation Alert Dialog
    if (showResetConfirmation) {
        AlertDialog(
            onDismissRequest = { showResetConfirmation = false },
            title = { Text("Reset Virtual Device?", fontWeight = FontWeight.Bold) },
            text = {
                Text("Are you sure you want to reset the virtual phone? All simulated browser history, accounts, gallery photos, messages, and notes will be restored to initial defaults.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetConfirmation = false
                        onResetDevice()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Confirm Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmation = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
