package com.example.ui.apps.camera

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CameraScreen(
    onCapturePhoto: (String, String, String, String) -> Unit,
    onOpenGallery: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isFrontCamera by remember { mutableStateOf(false) }
    var flashState by remember { mutableIntStateOf(0) } // 0: Auto, 1: On, 2: Off
    var selectedZoom by remember { mutableStateOf("1x") }
    var selectedMode by remember { mutableStateOf("PHOTO") }
    val modes = listOf("PORTRAIT", "PHOTO", "VIDEO", "PRO")

    var isFlashing by remember { mutableStateOf(false) }
    var lastCapturedNotice by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("camera_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Camera Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { flashState = (flashState + 1) % 3 }) {
                    Icon(
                        imageVector = when (flashState) {
                            0 -> Icons.Default.FlashAuto
                            1 -> Icons.Default.FlashOn
                            else -> Icons.Default.FlashOff
                        },
                        contentDescription = "Flash",
                        tint = if (flashState == 1) Color(0xFFFBBF24) else Color.White
                    )
                }

                Text(
                    text = "HDR",
                    color = Color(0xFF38BDF8),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )

                IconButton(onClick = {}) {
                    Icon(imageVector = Icons.Default.Timer, contentDescription = "Timer", tint = Color.White)
                }

                IconButton(onClick = {}) {
                    Icon(imageVector = Icons.Default.Settings, contentDescription = "Camera Settings", tint = Color.White)
                }
            }

            // Viewfinder Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 12.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF111827)),
                contentAlignment = Alignment.Center
            ) {
                // Viewfinder Framing Grid Marks
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceEvenly
                ) {
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.1f)))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.1f)))
                }

                // Center Autofocus Ring
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .border(1.5.dp, Color(0xFFFBBF24).copy(alpha = 0.6f), CircleShape)
                )

                // Camera Lens Description
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.align(Alignment.Center)
                ) {
                    Text(
                        text = if (isFrontCamera) "FRONT 12MP LENS" else "PRIMARY 50MP OIS",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "f/1.8 • 24mm • Dual Pixel",
                        color = Color.White.copy(alpha = 0.35f),
                        fontSize = 10.sp
                    )
                }

                // Zoom Level Controls
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black.copy(alpha = 0.5f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    listOf(".5x", "1x", "2x").forEach { zoom ->
                        Text(
                            text = zoom,
                            color = if (selectedZoom == zoom) Color(0xFFFBBF24) else Color.White.copy(alpha = 0.7f),
                            fontWeight = if (selectedZoom == zoom) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp,
                            modifier = Modifier.clickable { selectedZoom = zoom }
                        )
                    }
                }
            }

            // Camera Modes Selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                modes.forEach { mode ->
                    Text(
                        text = mode,
                        color = if (selectedMode == mode) Color(0xFFFBBF24) else Color.White.copy(alpha = 0.6f),
                        fontWeight = if (selectedMode == mode) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 12.sp,
                        modifier = Modifier.clickable { selectedMode = mode }
                    )
                }
            }

            // Bottom Shutter & Controls Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Shortcut to Gallery
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1E293B))
                        .clickable { onOpenGallery() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = "Gallery",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // SHUTTER BUTTON
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .border(3.dp, Color.White, CircleShape)
                        .padding(6.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable {
                            val timeStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                            val title = "IMG_$timeStr.jpg"
                            val palette = listOf("#3B82F6", "#10B981", "#EC4899", "#8B5CF6", "#F59E0B")
                            val chosenSeed = palette.random()

                            scope.launch {
                                isFlashing = true
                                delay(120)
                                isFlashing = false
                                onCapturePhoto(title, "Camera", chosenSeed, "camera_snap")
                                lastCapturedNotice = "Captured $title (Saved to SQLite)"
                                delay(2200)
                                lastCapturedNotice = null
                            }
                        }
                        .testTag("camera_shutter_button")
                )

                // SWITCH CAMERA FRONT/BACK
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1E293B))
                        .clickable { isFrontCamera = !isFrontCamera },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Cameraswitch,
                        contentDescription = "Switch Camera",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        // Shutter Screen Flash Animation
        AnimatedVisibility(
            visible = isFlashing,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize().background(Color.White))
        }

        // Capture Success Badge
        lastCapturedNotice?.let { notice ->
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 70.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xCC10B981))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(text = notice, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
