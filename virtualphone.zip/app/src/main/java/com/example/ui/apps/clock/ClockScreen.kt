package com.example.ui.apps.clock

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun ClockScreen(
    currentTimeString: String,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Alarm", "Clock", "Stopwatch", "Timer")

    // Stopwatch State
    var isStopwatchRunning by remember { mutableStateOf(false) }
    var stopwatchMillis by remember { mutableLongStateOf(0L) }
    val laps = remember { mutableStateListOf<String>() }

    LaunchedEffect(isStopwatchRunning) {
        var last = System.currentTimeMillis()
        while (isStopwatchRunning) {
            delay(30)
            val now = System.currentTimeMillis()
            stopwatchMillis += (now - last)
            last = now
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .testTag("clock_screen")
    ) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF1E293B),
            contentColor = Color.White,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = Color(0xFF6366F1)
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title, fontSize = 12.sp, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) },
                    icon = {
                        Icon(
                            imageVector = when (index) {
                                0 -> Icons.Default.Alarm
                                1 -> Icons.Default.Public
                                2 -> Icons.Default.Timer
                                else -> Icons.Default.HourglassBottom
                            },
                            contentDescription = title,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                )
            }
        }

        when (selectedTab) {
            0 -> {
                // ALARMS
                var alarm1On by remember { mutableStateOf(true) }
                var alarm2On by remember { mutableStateOf(false) }
                var alarm3On by remember { mutableStateOf(true) }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(text = "Alarms", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    item {
                        AlarmItem("06:30 AM", "Weekdays • Morning Run", alarm1On) { alarm1On = it }
                    }
                    item {
                        AlarmItem("07:45 AM", "Mon, Tue, Wed • Work Standup", alarm2On) { alarm2On = it }
                    }
                    item {
                        AlarmItem("09:00 AM", "Weekends • Casual", alarm3On) { alarm3On = it }
                    }
                }
            }
            1 -> {
                // WORLD CLOCK
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    item {
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(text = currentTimeString, fontSize = 54.sp, fontWeight = FontWeight.Light, color = Color.White)
                        Text(text = "Local Time • Silicon Valley (PST)", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(28.dp))
                        Text(text = "World Cities", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                    val cities = listOf(
                        Pair("New York", "+3 HRS • 01:24 PM"),
                        Pair("London", "+8 HRS • 06:24 PM"),
                        Pair("Tokyo", "+16 HRS • 02:24 AM (Next Day)"),
                        Pair("Sydney", "+18 HRS • 04:24 AM (Next Day)")
                    )
                    items(cities) { (city, diff) ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = city, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(text = diff, color = Color(0xFF6366F1), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
            2 -> {
                // STOPWATCH
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Spacer(modifier = Modifier.height(20.dp))

                    val mins = (stopwatchMillis / 60000)
                    val secs = (stopwatchMillis % 60000) / 1000
                    val hund = (stopwatchMillis % 1000) / 10
                    val formatted = String.format("%02d:%02d.%02d", mins, secs, hund)

                    Text(text = formatted, fontSize = 52.sp, fontWeight = FontWeight.Light, color = Color.White)

                    // Laps list
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 16.dp)
                    ) {
                        items(laps) { lap ->
                            Text(text = lap, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp))
                        }
                    }

                    // Stopwatch Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Button(
                            onClick = {
                                if (isStopwatchRunning) {
                                    laps.add(0, "Lap ${laps.size + 1}: $formatted")
                                } else {
                                    stopwatchMillis = 0L
                                    laps.clear()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                        ) {
                            Text(text = if (isStopwatchRunning) "Lap" else "Reset")
                        }

                        Button(
                            onClick = { isStopwatchRunning = !isStopwatchRunning },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isStopwatchRunning) Color(0xFFEF4444) else Color(0xFF22C55E)
                            )
                        ) {
                            Icon(imageVector = if (isStopwatchRunning) Icons.Default.Stop else Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = if (isStopwatchRunning) "Stop" else "Start")
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
            3 -> {
                // TIMER
                var timerSeconds by remember { mutableIntStateOf(180) }
                var isTimerRunning by remember { mutableStateOf(false) }

                LaunchedEffect(isTimerRunning) {
                    while (isTimerRunning && timerSeconds > 0) {
                        delay(1000)
                        timerSeconds--
                    }
                    if (timerSeconds == 0) isTimerRunning = false
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    val m = timerSeconds / 60
                    val s = timerSeconds % 60
                    Text(text = String.format("%02d:%02d", m, s), fontSize = 60.sp, fontWeight = FontWeight.Light, color = Color.White)
                    Spacer(modifier = Modifier.height(30.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Button(
                            onClick = {
                                isTimerRunning = false
                                timerSeconds = 180
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = { isTimerRunning = !isTimerRunning },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isTimerRunning) Color(0xFFEF4444) else Color(0xFF6366F1)
                            )
                        ) {
                            Text(if (isTimerRunning) "Pause" else "Start")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AlarmItem(
    time: String,
    label: String,
    isOn: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = time, color = if (isOn) Color.White else Color.White.copy(alpha = 0.4f), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(text = label, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            }
            Switch(
                checked = isOn,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF6366F1))
            )
        }
    }
}
