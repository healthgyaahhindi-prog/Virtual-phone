package com.example.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.ContactPage
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.StickyNote2
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.VirtualAppEntity

@Composable
fun AppIconGraphic(
    iconName: String,
    size: Dp = 48.dp,
    modifier: Modifier = Modifier
) {
    val (bgColor, iconVector, iconTint) = when (iconName) {
        "phone" -> Triple(Color(0xFF22C55E), Icons.Default.Phone, Color.White)
        "message" -> Triple(Color(0xFF3B82F6), Icons.Default.Message, Color.White)
        "chrome" -> Triple(Color(0xFFEA580C), Icons.Default.Language, Color.White)
        "camera" -> Triple(Color(0xFFE2E8F0), Icons.Default.CameraAlt, Color(0xFF1E293B))
        "gallery" -> Triple(Color(0xFFEC4899), Icons.Default.PhotoLibrary, Color.White)
        "calculate" -> Triple(Color(0xFFF97316), Icons.Default.Calculate, Color.White)
        "clock" -> Triple(Color(0xFF6366F1), Icons.Default.Schedule, Color.White)
        "calendar" -> Triple(Color(0xFF0EA5E9), Icons.Default.CalendarMonth, Color.White)
        "notes" -> Triple(Color(0xFFEAB308), Icons.Default.StickyNote2, Color.White)
        "folder" -> Triple(Color(0xFF14B8A6), Icons.Default.Folder, Color.White)
        "music" -> Triple(Color(0xFFA855F7), Icons.Default.MusicNote, Color.White)
        "download" -> Triple(Color(0xFF0284C7), Icons.Default.FileDownload, Color.White)
        "contacts" -> Triple(Color(0xFF10B981), Icons.Default.ContactPage, Color.White)
        "settings" -> Triple(Color(0xFF64748B), Icons.Default.Settings, Color.White)
        "bug" -> Triple(Color(0xFFEF4444), Icons.Default.BugReport, Color.White)
        else -> Triple(Color(0xFF6366F1), Icons.Default.Language, Color.White)
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(bgColor),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = iconVector,
            contentDescription = iconName,
            tint = iconTint,
            modifier = Modifier.size(size * 0.55f)
        )
    }
}

@Composable
fun HomeAppItem(
    app: VirtualAppEntity,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(72.dp)
            .clickable { onClick() }
            .padding(vertical = 4.dp)
            .testTag("app_icon_${app.packageName}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIconGraphic(iconName = app.iconName, size = 52.dp)
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = app.appName,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Normal,
            maxLines = 1
        )
    }
}

@Composable
fun HomeClockWidget(
    timeString: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = timeString,
            fontSize = 62.sp,
            fontWeight = FontWeight.Light,
            color = Color.White,
            letterSpacing = (-1).sp
        )
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Thursday, Oct 1",
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.85f),
                fontWeight = FontWeight.Normal
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Default.Cloud,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "72°F Sunny",
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.85f)
            )
        }
    }
}

@Composable
fun HomeSearchBarWidget(
    onSearchClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(RoundedCornerShape(25.dp))
            .background(Color.White.copy(alpha = 0.22f))
            .clickable { onSearchClick() }
            .padding(horizontal = 16.dp)
            .testTag("home_search_bar"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "G",
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF38BDF8)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "Search or type URL...",
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.75f)
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Voice Search",
                tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
