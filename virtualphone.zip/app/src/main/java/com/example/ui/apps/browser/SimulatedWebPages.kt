package com.example.ui.apps.browser

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.BrowserAccountEntity

@Composable
fun RenderSimulatedWebPage(
    url: String,
    account: BrowserAccountEntity?,
    onNavigate: (String, String) -> Unit,
    onLoginSimMail: (String, String) -> Unit,
    onLogoutSimMail: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cleanUrl = url.trim().lowercase()

    when {
        cleanUrl.contains("nexus.search") -> NexusSearchPage(onNavigate = onNavigate, modifier = modifier)
        cleanUrl.contains("simmail.com") -> SimMailPage(
            account = account,
            onLogin = onLoginSimMail,
            onLogout = onLogoutSimMail,
            modifier = modifier
        )
        cleanUrl.contains("nexusfeed.com") -> NexusFeedPage(
            account = account,
            onNavigate = onNavigate,
            modifier = modifier
        )
        cleanUrl.contains("dailynews.org") -> DailyNewsPage(onNavigate = onNavigate, modifier = modifier)
        cleanUrl.contains("omnipedia.org") -> OmniPediaPage(onNavigate = onNavigate, modifier = modifier)
        else -> GenericWebPage(url = url, onNavigate = onNavigate, modifier = modifier)
    }
}

// 1. NEXUS SEARCH ENGINE
@Composable
fun NexusSearchPage(
    onNavigate: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by remember { mutableStateOf("") }
    var searchExecuted by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Nexus", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6366F1))
                Text(text = "Search", fontSize = 32.sp, fontWeight = FontWeight.Light, color = Color(0xFF38BDF8))
            }
            Text(
                text = "Fast, Private & Persistent Web Simulation",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { query = it; searchExecuted = false },
                placeholder = { Text("Search the simulated web...", color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp) },
                trailingIcon = {
                    IconButton(onClick = { if (query.isNotBlank()) searchExecuted = true }) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF6366F1))
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF6366F1),
                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Portal shortcuts
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                QuickWebShortcut("SimMail", Color(0xFF3B82F6)) {
                    onNavigate("https://simmail.com", "SimMail Portal")
                }
                QuickWebShortcut("NexusFeed", Color(0xFF8B5CF6)) {
                    onNavigate("https://nexusfeed.com", "NexusFeed Social")
                }
                QuickWebShortcut("News", Color(0xFFEF4444)) {
                    onNavigate("https://dailynews.org", "Daily Global News")
                }
                QuickWebShortcut("Wiki", Color(0xFF10B981)) {
                    onNavigate("https://omnipedia.org", "OmniPedia Knowledge")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            Spacer(modifier = Modifier.height(16.dp))
        }

        if (searchExecuted && query.isNotBlank()) {
            item {
                Text(
                    text = "Results for \"$query\"",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            val simulatedResults = listOf(
                Pair("$query - Comprehensive Guide & Overview", "https://nexus.search/q/${query.replace(" ", "_")}"),
                Pair("Latest Updates and Discussions on $query", "https://nexusfeed.com/tag/${query.replace(" ", "_")}"),
                Pair("OmniPedia Reference Article: $query", "https://omnipedia.org/wiki/${query.replace(" ", "_")}")
            )

            items(simulatedResults) { (title, link) ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onNavigate(link, title) }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = link, color = Color(0xFF38BDF8), fontSize = 11.sp)
                        Text(text = title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "Explore in-depth simulated articles, facts, and discussions related to $query in the virtual ecosystem.",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        } else {
            item {
                Text(
                    text = "Trending Searches",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            val trends = listOf(
                "Native Jetpack Compose Architecture",
                "Persistent Android SQLite Room Database",
                "Virtual Phone OS 15 Features",
                "Future of Mobile Computing 2026"
            )

            items(trends) { topic ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            query = topic
                            searchExecuted = true
                        }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = Color.White.copy(alpha = 0.4f), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = topic, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun QuickWebShortcut(name: String, color: Color, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Text(text = name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = name, color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
    }
}

// 2. SIMMAIL PORTAL (WITH PERSISTENT LOGIN STATE)
@Composable
fun SimMailPage(
    account: BrowserAccountEntity?,
    onLogin: (String, String) -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    var emailInput by remember { mutableStateOf("user@virtualphone.net") }
    var passwordInput by remember { mutableStateOf("••••••••") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = Color(0xFF38BDF8))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "SimMail", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                if (account != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = account.displayName, color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(onClick = onLogout) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Logout, contentDescription = "Log out", tint = Color(0xFFEF4444))
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            Spacer(modifier = Modifier.height(16.dp))
        }

        if (account == null) {
            // Login Form
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(text = "Sign in to SimMail", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "Login state will persist in the virtual device database even after closing the app.",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Email", color = Color.White.copy(alpha = 0.6f)) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF38BDF8),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("Password", color = Color.White.copy(alpha = 0.6f)) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF38BDF8),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { onLogin(emailInput, "Alex Carter") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Login, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Sign In & Persist Session", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            // Logged in Inbox
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Inbox (3 Messages)", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "Session: Active (Room DB)", color = Color(0xFF10B981), fontSize = 11.sp)
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            val emails = listOf(
                Triple("Android Platform Team", "Welcome to Virtual OS 15", "Your virtual smartphone instance has been successfully provisioned with full offline Room persistence."),
                Triple("Nexus Cloud Services", "Security Alert: New Sign-in", "A new sign-in was recorded from your simulated device. Session token is securely stored."),
                Triple("Daily Digest", "Top Technology Headlines Today", "Discover the latest innovations in AI, embedded native software, and distributed computing.")
            )

            items(emails) { (from, subject, snippet) ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = from, color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(text = "Today", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                        }
                        Text(text = subject, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(text = snippet, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// 3. NEXUSFEED SOCIAL MEDIA
@Composable
fun NexusFeedPage(
    account: BrowserAccountEntity?,
    onNavigate: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var newPostText by remember { mutableStateOf("") }
    val posts = remember {
        mutableStateListOf(
            FeedPost(1, "Elena Rostova", "@elena_dev", "Just launched our native Compose simulated OS! Data persists across device restarts.", 42, false),
            FeedPost(2, "Tech Insider", "@techinsider", "Simulated environments inside mobile apps open up incredible testing capabilities without emulators.", 89, false),
            FeedPost(3, "Virtual Explorer", "@vexplorer", "Exploring the simulated web through NexusSearch and SimMail.", 15, true)
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Nexus", color = Color(0xFF8B5CF6), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(text = "Feed", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Light)
            }
            Spacer(modifier = Modifier.height(12.dp))

            // Create Post Box
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    OutlinedTextField(
                        value = newPostText,
                        onValueChange = { newPostText = it },
                        placeholder = { Text("What's happening in the virtual phone?", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF8B5CF6),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = {
                                if (newPostText.isNotBlank()) {
                                    posts.add(0, FeedPost(System.currentTimeMillis(), account?.displayName ?: "Virtual User", "@me", newPostText, 1, true))
                                    newPostText = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6)),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Post", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
        }

        items(posts, key = { it.id }) { post ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF8B5CF6)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = post.author.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = post.author, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(text = post.handle, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = post.content, color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            val index = posts.indexOf(post)
                            if (index != -1) {
                                val current = posts[index]
                                posts[index] = current.copy(
                                    likes = if (current.isLiked) current.likes - 1 else current.likes + 1,
                                    isLiked = !current.isLiked
                                )
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (post.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Like",
                            tint = if (post.isLiked) Color(0xFFEC4899) else Color.White.copy(alpha = 0.5f),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "${post.likes}", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

data class FeedPost(
    val id: Long,
    val author: String,
    val handle: String,
    val content: String,
    val likes: Int,
    val isLiked: Boolean
)

// 4. DAILY NEWS WIRE
@Composable
fun DailyNewsPage(
    onNavigate: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val articles = listOf(
        Pair("Next-Gen Native Android Development in 2026", "Modern declarative UI with Jetpack Compose has streamlined app architecture, enabling rich embedded operating system simulations inside single native applications."),
        Pair("Breakthrough in Edge AI & Local Device Persistence", "Smartphones now leverage real-time on-device vector engines and SQLite Room databases to provide instantaneous state recovery without cloud latency."),
        Pair("Sustainable Tech: Solar Glass & Renewable Data Centers", "Renewable energy breakthroughs power global edge compute nodes, reducing carbon footprints across cloud ecosystems.")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Newspaper, contentDescription = null, tint = Color(0xFFEF4444))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Daily Global News", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        items(articles) { (headline, body) ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "TOP STORY", color = Color(0xFFEF4444), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = headline, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = body, color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

// 5. OMNIPEDIA KNOWLEDGE WIKI
@Composable
fun OmniPediaPage(
    onNavigate: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.AutoMirrored.Filled.Article, contentDescription = null, tint = Color(0xFF10B981))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "OmniPedia", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Text(text = "The Free Simulated Encyclopedia", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
            Spacer(modifier = Modifier.height(16.dp))

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "Article of the Day: Android (operating system)", color = Color(0xFF10B981), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Android is a mobile operating system based on a modified version of the Linux kernel and other open-source software, designed primarily for touchscreen mobile devices such as smartphones and tablets. In this simulation, an entire virtual smartphone environment runs inside a native Kotlin Compose application, with complete Room persistence.",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }
    }
}

// 6. GENERIC SIMULATED WEB PAGE
@Composable
fun GenericWebPage(
    url: String,
    onNavigate: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = "Secure", tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Secure Simulated Website", color = Color(0xFF10B981), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Simulated Web Content", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(text = url, color = Color(0xFF38BDF8), fontSize = 12.sp)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "This page is rendered by the VirtualPhone simulated browser engine. All navigation, bookmarks, and history entries are saved persistently in your local device SQLite Room database.",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { onNavigate("https://nexus.search", "Nexus Search") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
                ) {
                    Text(text = "Return to Nexus Search", color = Color.White)
                }
            }
        }
    }
}
