package com.example.ui.apps.calculator

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CalculatorScreen(
    modifier: Modifier = Modifier
) {
    var expression by remember { mutableStateOf("") }
    var resultText by remember { mutableStateOf("0") }

    fun calculate(expr: String): String {
        return try {
            val sanitized = expr.replace("×", "*").replace("÷", "/")
            if (sanitized.isEmpty()) return "0"
            // Simple expression evaluator
            val res = evalSimple(sanitized)
            if (res % 1.0 == 0.0) res.toLong().toString() else "%.4f".format(res).trimEnd('0').trimEnd('.')
        } catch (e: Exception) {
            "Error"
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp)
            .testTag("calculator_screen"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Display Area
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = expression,
                fontSize = 28.sp,
                color = Color.White.copy(alpha = 0.7f),
                textAlign = TextAlign.End,
                maxLines = 2
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = resultText,
                fontSize = 48.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.End,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Keypad Grid 4x5
        val buttons = listOf(
            listOf("C", "(", ")", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "-"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "⌫", "=")
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            buttons.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    row.forEach { label ->
                        CalcButton(
                            label = label,
                            onClick = {
                                when (label) {
                                    "C" -> {
                                        expression = ""
                                        resultText = "0"
                                    }
                                    "⌫" -> {
                                        if (expression.isNotEmpty()) {
                                            expression = expression.dropLast(1)
                                            resultText = calculate(expression)
                                        }
                                    }
                                    "=" -> {
                                        resultText = calculate(expression)
                                        expression = resultText
                                    }
                                    else -> {
                                        expression += label
                                        resultText = calculate(expression)
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
fun CalcButton(
    label: String,
    onClick: () -> Unit
) {
    val isOperator = label in listOf("÷", "×", "-", "+", "=")
    val isSpecial = label in listOf("C", "(", ")", "⌫")

    val bgColor = when {
        label == "=" -> Color(0xFF22C55E)
        isOperator -> Color(0xFF6366F1)
        isSpecial -> Color(0xFF334155)
        else -> Color(0xFF1E293B)
    }

    Box(
        modifier = Modifier
            .size(68.dp)
            .clip(CircleShape)
            .background(bgColor)
            .clickable { onClick() }
            .testTag("calc_btn_$label"),
        contentAlignment = Alignment.Center
    ) {
        if (label == "⌫") {
            Icon(Icons.Default.Backspace, contentDescription = "Backspace", tint = Color.White, modifier = Modifier.size(20.dp))
        } else {
            Text(
                text = label,
                fontSize = if (isOperator) 24.sp else 22.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
        }
    }
}

private fun evalSimple(str: String): Double {
    // Basic parser for +, -, *, /
    val tokens = mutableListOf<String>()
    var numBuf = ""
    for (ch in str) {
        if (ch in "+-*/") {
            if (numBuf.isNotEmpty()) {
                tokens.add(numBuf)
                numBuf = ""
            }
            tokens.add(ch.toString())
        } else if (ch.isDigit() || ch == '.') {
            numBuf += ch
        }
    }
    if (numBuf.isNotEmpty()) tokens.add(numBuf)

    if (tokens.isEmpty()) return 0.0

    // Multiplications & Divisions first
    val intermediate = mutableListOf<String>()
    var i = 0
    while (i < tokens.size) {
        val t = tokens[i]
        if (t == "*" || t == "/") {
            val prev = intermediate.removeAt(intermediate.size - 1).toDoubleOrNull() ?: 0.0
            val next = tokens.getOrNull(i + 1)?.toDoubleOrNull() ?: 1.0
            val calc = if (t == "*") prev * next else (if (next != 0.0) prev / next else 0.0)
            intermediate.add(calc.toString())
            i += 2
        } else {
            intermediate.add(t)
            i++
        }
    }

    // Additions & Subtractions
    var total = intermediate.getOrNull(0)?.toDoubleOrNull() ?: 0.0
    var j = 1
    while (j < intermediate.size) {
        val op = intermediate[j]
        val nextVal = intermediate.getOrNull(j + 1)?.toDoubleOrNull() ?: 0.0
        if (op == "+") total += nextVal
        if (op == "-") total -= nextVal
        j += 2
    }
    return total
}
