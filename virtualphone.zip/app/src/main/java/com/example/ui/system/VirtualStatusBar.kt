package com.example.ui.system

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.NetworkCell
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.VirtualNotificationEntity

@Composable
fun VirtualStatusBar(
    timeString: String,
    batteryLevel: Int,
    isWifiOn: Boolean,
    notifications: List<VirtualNotificationEntity>,
    onStatusBarClicked: () -> Unit,
    modifier: Modifier = Modifier,
    isDarkContent: Boolean = false
) {
    val contentColor = if (isDarkContent) Color.Black.copy(alpha = 0.85f) else Color.White

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(34.dp)
            .clickable { onStatusBarClicked() }
            .padding(horizontal = 16.dp)
            .testTag("virtual_status_bar"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left side: Time + Notification icons
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = timeString,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = contentColor
            )
            Spacer(modifier = Modifier.width(8.dp))
            // Active notification icons
            if (notifications.isNotEmpty()) {
                val hasMsg = notifications.any { it.iconName == "message" }
                val hasCam = notifications.any { it.iconName == "camera" }
                val hasDl = notifications.any { it.iconName == "download" }

                if (hasMsg) {
                    Icon(
                        imageVector = Icons.Default.Message,
                        contentDescription = "Message Notification",
                        tint = contentColor.copy(alpha = 0.8f),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }
                if (hasCam) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Camera Notification",
                        tint = contentColor.copy(alpha = 0.8f),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }
                if (hasDl) {
                    Icon(
                        imageVector = Icons.Default.FileDownload,
                        contentDescription = "Download Notification",
                        tint = contentColor.copy(alpha = 0.8f),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }
                if (!hasMsg && !hasCam && !hasDl) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notification",
                        tint = contentColor.copy(alpha = 0.8f),
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }

        // Center punch-hole camera simulation
        Box(
            modifier = Modifier
                .size(11.dp)
                .clip(CircleShape)
                .background(Color(0xFF0F172A))
        )

        // Right side: Cellular, Wi-Fi, Battery
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isWifiOn) {
                Icon(
                    imageVector = Icons.Default.Wifi,
                    contentDescription = "Wi-Fi Connected",
                    tint = contentColor,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
            Icon(
                imageVector = Icons.Default.NetworkCell,
                contentDescription = "5G Cellular",
                tint = contentColor,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text(
                text = "5G",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = contentColor
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "$batteryLevel%",
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = contentColor
            )
            Spacer(modifier = Modifier.width(2.dp))
            Icon(
                imageVector = Icons.Default.BatteryChargingFull,
                contentDescription = "Battery",
                tint = contentColor,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
