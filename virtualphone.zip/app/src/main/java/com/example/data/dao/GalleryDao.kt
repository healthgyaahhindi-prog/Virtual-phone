package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.GalleryItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GalleryDao {
    @Query("SELECT * FROM gallery_items ORDER BY dateAdded DESC")
    fun getAllItemsFlow(): Flow<List<GalleryItemEntity>>

    @Query("SELECT COUNT(*) FROM gallery_items")
    suspend fun getGalleryCount(): Int

    @Query("SELECT * FROM gallery_items WHERE id = :id LIMIT 1")
    suspend fun getItemById(id: Long): GalleryItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: GalleryItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<GalleryItemEntity>)

    @Query("DELETE FROM gallery_items WHERE id = :id")
    suspend fun deleteItem(id: Long)

    @Query("UPDATE gallery_items SET isFavorite = :isFav WHERE id = :id")
    suspend fun toggleFavorite(id: Long, isFav: Boolean)

    @Query("DELETE FROM gallery_items")
    suspend fun clearGallery()
}
