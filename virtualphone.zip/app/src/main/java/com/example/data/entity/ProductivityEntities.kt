package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "virtual_notes")
data class VirtualNoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val colorHex: String = "#FEF08A",
    val updatedAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
)

@Entity(tableName = "calendar_events")
data class CalendarEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val dateTimestamp: Long, // midnight millis of the day
    val timeString: String = "10:00 AM",
    val colorHex: String = "#6366F1"
)

@Entity(tableName = "download_items")
data class DownloadItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fileName: String,
    val fileSize: String,
    val fileType: String,
    val downloadedTimestamp: Long = System.currentTimeMillis(),
    val status: String = "COMPLETED" // "COMPLETED", "IN_PROGRESS"
)
