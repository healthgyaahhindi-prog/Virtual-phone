package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.CalendarEventEntity
import com.example.data.entity.DownloadItemEntity
import com.example.data.entity.VirtualNoteEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductivityDao {
    // Notes
    @Query("SELECT * FROM virtual_notes ORDER BY isPinned DESC, updatedAt DESC")
    fun getAllNotesFlow(): Flow<List<VirtualNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: VirtualNoteEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotes(notes: List<VirtualNoteEntity>)

    @Update
    suspend fun updateNote(note: VirtualNoteEntity)

    @Query("DELETE FROM virtual_notes WHERE id = :id")
    suspend fun deleteNote(id: Long)

    @Query("DELETE FROM virtual_notes")
    suspend fun clearNotes()

    // Calendar
    @Query("SELECT * FROM calendar_events ORDER BY dateTimestamp ASC")
    fun getAllEventsFlow(): Flow<List<CalendarEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: CalendarEventEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(events: List<CalendarEventEntity>)

    @Query("DELETE FROM calendar_events WHERE id = :id")
    suspend fun deleteEvent(id: Long)

    @Query("DELETE FROM calendar_events")
    suspend fun clearEvents()

    // Downloads
    @Query("SELECT * FROM download_items ORDER BY downloadedTimestamp DESC")
    fun getAllDownloadsFlow(): Flow<List<DownloadItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(item: DownloadItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownloads(items: List<DownloadItemEntity>)

    @Query("DELETE FROM download_items WHERE id = :id")
    suspend fun deleteDownload(id: Long)

    @Query("DELETE FROM download_items")
    suspend fun clearDownloads()
}
