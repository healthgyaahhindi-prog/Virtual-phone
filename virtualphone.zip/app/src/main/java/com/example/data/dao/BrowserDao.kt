package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.BrowserAccountEntity
import com.example.data.entity.BrowserBookmarkEntity
import com.example.data.entity.BrowserHistoryEntity
import com.example.data.entity.BrowserProfileEntity
import com.example.data.entity.BrowserTabEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BrowserDao {
    // Profile - exactly ONE persistent profile for the virtual device
    @Query("SELECT * FROM browser_profile WHERE deviceId = :deviceId OR deviceId = 'primary_device' ORDER BY id ASC LIMIT 1")
    fun getProfileFlow(deviceId: String = "primary_device"): Flow<BrowserProfileEntity?>

    @Query("SELECT * FROM browser_profile WHERE deviceId = :deviceId OR deviceId = 'primary_device' ORDER BY id ASC LIMIT 1")
    suspend fun getProfileDirect(deviceId: String = "primary_device"): BrowserProfileEntity?

    @Query("SELECT * FROM browser_profile ORDER BY id ASC LIMIT 1")
    fun getAnyProfileFlow(): Flow<BrowserProfileEntity?>

    @Query("SELECT * FROM browser_profile ORDER BY id ASC LIMIT 1")
    suspend fun getAnyProfileDirect(): BrowserProfileEntity?

    @Query("SELECT COUNT(*) FROM browser_profile")
    suspend fun getProfileCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: BrowserProfileEntity)

    @Query("UPDATE browser_profile SET isFirstRunDone = :isDone, lastWriteTimestamp = :timestamp WHERE deviceId = :deviceId OR deviceId = 'primary_device'")
    suspend fun updateFirstRunDone(isDone: Boolean, timestamp: Long, deviceId: String = "primary_device")

    @Query("UPDATE browser_profile SET lastActiveUrl = :url, lastActiveTitle = :title, lastWriteTimestamp = :timestamp WHERE deviceId = :deviceId OR deviceId = 'primary_device'")
    suspend fun updateLastActivePage(url: String, title: String, timestamp: Long, deviceId: String = "primary_device")

    @Query("UPDATE browser_profile SET lastReadTimestamp = :timestamp WHERE deviceId = :deviceId OR deviceId = 'primary_device'")
    suspend fun updateLastRead(timestamp: Long, deviceId: String = "primary_device")

    // History
    @Query("SELECT * FROM browser_history ORDER BY visitedTimestamp DESC")
    fun getHistoryFlow(): Flow<List<BrowserHistoryEntity>>

    @Query("SELECT COUNT(*) FROM browser_history")
    suspend fun getHistoryCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(item: BrowserHistoryEntity): Long

    @Query("DELETE FROM browser_history")
    suspend fun clearHistory()

    // Bookmarks
    @Query("SELECT * FROM browser_bookmarks ORDER BY createdTimestamp DESC")
    fun getBookmarksFlow(): Flow<List<BrowserBookmarkEntity>>

    @Query("SELECT COUNT(*) FROM browser_bookmarks")
    suspend fun getBookmarksCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BrowserBookmarkEntity): Long

    @Query("DELETE FROM browser_bookmarks WHERE id = :id")
    suspend fun deleteBookmark(id: Long)

    @Query("DELETE FROM browser_bookmarks")
    suspend fun clearBookmarks()

    // Tabs
    @Query("SELECT * FROM browser_tabs ORDER BY createdTimestamp ASC")
    fun getTabsFlow(): Flow<List<BrowserTabEntity>>

    @Query("SELECT COUNT(*) FROM browser_tabs")
    suspend fun getTabsCount(): Int

    @Query("SELECT * FROM browser_tabs")
    suspend fun getTabsDirect(): List<BrowserTabEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTab(tab: BrowserTabEntity): Long

    @Update
    suspend fun updateTab(tab: BrowserTabEntity)

    @Query("DELETE FROM browser_tabs WHERE id = :id")
    suspend fun deleteTab(id: Long)

    @Query("DELETE FROM browser_tabs")
    suspend fun clearTabs()

    // Accounts
    @Query("SELECT * FROM browser_accounts ORDER BY lastLoginTimestamp DESC")
    fun getAccountsFlow(): Flow<List<BrowserAccountEntity>>

    @Query("SELECT COUNT(*) FROM browser_accounts")
    suspend fun getAccountsCount(): Int

    @Query("SELECT * FROM browser_accounts WHERE siteDomain = :domain ORDER BY lastLoginTimestamp DESC LIMIT 1")
    suspend fun getAccountForDomain(domain: String): BrowserAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccount(account: BrowserAccountEntity): Long

    @Query("DELETE FROM browser_accounts WHERE id = :id")
    suspend fun deleteAccount(id: Long)

    @Query("DELETE FROM browser_accounts WHERE siteDomain = :domain")
    suspend fun deleteAccountForDomain(domain: String)

    @Query("DELETE FROM browser_accounts")
    suspend fun clearAccounts()
}
