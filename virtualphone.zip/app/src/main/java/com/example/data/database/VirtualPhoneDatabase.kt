package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.BrowserDao
import com.example.data.dao.CommunicationDao
import com.example.data.dao.GalleryDao
import com.example.data.dao.ProductivityDao
import com.example.data.dao.VirtualAppDao
import com.example.data.dao.VirtualDeviceDao
import com.example.data.entity.BrowserAccountEntity
import com.example.data.entity.BrowserBookmarkEntity
import com.example.data.entity.BrowserHistoryEntity
import com.example.data.entity.BrowserProfileEntity
import com.example.data.entity.BrowserTabEntity
import com.example.data.entity.CalendarEventEntity
import com.example.data.entity.CallLogEntity
import com.example.data.entity.ContactEntity
import com.example.data.entity.DownloadItemEntity
import com.example.data.entity.GalleryItemEntity
import com.example.data.entity.MessageEntity
import com.example.data.entity.RecentAppEntity
import com.example.data.entity.VirtualAppEntity
import com.example.data.entity.VirtualDeviceEntity
import com.example.data.entity.VirtualNoteEntity
import com.example.data.entity.VirtualNotificationEntity

@Database(
    entities = [
        VirtualDeviceEntity::class,
        VirtualAppEntity::class,
        RecentAppEntity::class,
        BrowserProfileEntity::class,
        BrowserHistoryEntity::class,
        BrowserBookmarkEntity::class,
        BrowserTabEntity::class,
        BrowserAccountEntity::class,
        GalleryItemEntity::class,
        ContactEntity::class,
        MessageEntity::class,
        CallLogEntity::class,
        VirtualNotificationEntity::class,
        VirtualNoteEntity::class,
        CalendarEventEntity::class,
        DownloadItemEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class VirtualPhoneDatabase : RoomDatabase() {

    abstract fun virtualDeviceDao(): VirtualDeviceDao
    abstract fun virtualAppDao(): VirtualAppDao
    abstract fun browserDao(): BrowserDao
    abstract fun galleryDao(): GalleryDao
    abstract fun communicationDao(): CommunicationDao
    abstract fun productivityDao(): ProductivityDao

    companion object {
        const val DATABASE_NAME = "virtual_phone_database.db"

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE browser_profile ADD COLUMN deviceId TEXT NOT NULL DEFAULT 'primary_device'")
                db.execSQL("ALTER TABLE browser_profile ADD COLUMN isFirstRunDone INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE browser_profile ADD COLUMN lastActiveUrl TEXT NOT NULL DEFAULT 'https://nexus.search'")
                db.execSQL("ALTER TABLE browser_profile ADD COLUMN lastActiveTitle TEXT NOT NULL DEFAULT 'Nexus Search'")
                db.execSQL("ALTER TABLE browser_profile ADD COLUMN lastWriteTimestamp INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE browser_profile ADD COLUMN lastReadTimestamp INTEGER NOT NULL DEFAULT 0")
            }
        }

        @Volatile
        private var instance: VirtualPhoneDatabase? = null

        fun getInstance(context: Context): VirtualPhoneDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    VirtualPhoneDatabase::class.java,
                    DATABASE_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration(dropAllTables = false)
                    .fallbackToDestructiveMigrationOnDowngrade(dropAllTables = false)
                    .build()
                    .also { instance = it }
            }
        }
    }
}
