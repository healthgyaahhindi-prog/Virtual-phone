package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "virtual_device")
data class VirtualDeviceEntity(
    @PrimaryKey
    val id: String = "primary_device",
    val modelName: String = "Pixel Virtual Pro",
    val osVersion: String = "Android 15 (Virtual Edition)",
    val firstLaunchDone: Boolean = true,
    val wallpaperId: Int = 1,
    val isDarkTheme: Boolean = true,
    val brightness: Float = 0.85f,
    val volumeLevel: Float = 0.70f,
    val isWifiOn: Boolean = true,
    val isBluetoothOn: Boolean = true,
    val isCellularOn: Boolean = true,
    val batteryLevel: Int = 88,
    val lastBootTime: Long = System.currentTimeMillis(),
    val lastWriteTime: Long = System.currentTimeMillis(),
    val lastReadTime: Long = System.currentTimeMillis()
)
