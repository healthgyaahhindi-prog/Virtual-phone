package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "virtual_apps")
data class VirtualAppEntity(
    @PrimaryKey
    val packageName: String,
    val appName: String,
    val iconName: String,
    val category: String,
    val isSystemApp: Boolean = true,
    val isInstalled: Boolean = true,
    val orderIndex: Int = 0,
    val isDockApp: Boolean = false
)

@Entity(tableName = "recent_apps")
data class RecentAppEntity(
    @PrimaryKey
    val packageName: String,
    val appName: String,
    val iconName: String,
    val lastOpenedTime: Long = System.currentTimeMillis()
)
