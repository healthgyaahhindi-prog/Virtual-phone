package com.example.data.repository

import com.example.data.database.VirtualPhoneDatabase
import com.example.data.entity.BrowserAccountEntity
import com.example.data.entity.BrowserBookmarkEntity
import com.example.data.entity.BrowserHistoryEntity
import com.example.data.entity.BrowserProfileEntity
import com.example.data.entity.BrowserTabEntity
import com.example.data.entity.CalendarEventEntity
import com.example.data.entity.CallLogEntity
import com.example.data.entity.ContactEntity
import com.example.data.entity.DownloadItemEntity
import com.example.data.entity.GalleryItemEntity
import com.example.data.entity.MessageEntity
import com.example.data.entity.RecentAppEntity
import com.example.data.entity.VirtualAppEntity
import com.example.data.entity.VirtualDeviceEntity
import com.example.data.entity.VirtualNoteEntity
import com.example.data.entity.VirtualNotificationEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class VirtualPhoneRepository(private val database: VirtualPhoneDatabase) {

    private val deviceDao = database.virtualDeviceDao()
    private val appDao = database.virtualAppDao()
    private val browserDao = database.browserDao()
    private val galleryDao = database.galleryDao()
    private val commDao = database.communicationDao()
    private val prodDao = database.productivityDao()

    // Device flows
    val deviceFlow: Flow<VirtualDeviceEntity?> = deviceDao.getDeviceFlow()
    val appsFlow: Flow<List<VirtualAppEntity>> = appDao.getAllAppsFlow()
    val dockAppsFlow: Flow<List<VirtualAppEntity>> = appDao.getDockAppsFlow()
    val recentAppsFlow: Flow<List<RecentAppEntity>> = appDao.getRecentAppsFlow()

    // Browser flows
    val browserProfileFlow: Flow<BrowserProfileEntity?> = browserDao.getProfileFlow()
    val browserHistoryFlow: Flow<List<BrowserHistoryEntity>> = browserDao.getHistoryFlow()
    val browserBookmarksFlow: Flow<List<BrowserBookmarkEntity>> = browserDao.getBookmarksFlow()
    val browserTabsFlow: Flow<List<BrowserTabEntity>> = browserDao.getTabsFlow()
    val browserAccountsFlow: Flow<List<BrowserAccountEntity>> = browserDao.getAccountsFlow()

    // Media & Comms flows
    val galleryFlow: Flow<List<GalleryItemEntity>> = galleryDao.getAllItemsFlow()
    val contactsFlow: Flow<List<ContactEntity>> = commDao.getAllContactsFlow()
    val messagesFlow: Flow<List<MessageEntity>> = commDao.getAllMessagesFlow()
    fun getMessagesForContact(contactId: Long): Flow<List<MessageEntity>> = commDao.getMessagesForContactFlow(contactId)
    val callLogsFlow: Flow<List<CallLogEntity>> = commDao.getCallLogsFlow()
    val notificationsFlow: Flow<List<VirtualNotificationEntity>> = commDao.getNotificationsFlow()

    // Productivity flows
    val notesFlow: Flow<List<VirtualNoteEntity>> = prodDao.getAllNotesFlow()
    val eventsFlow: Flow<List<CalendarEventEntity>> = prodDao.getAllEventsFlow()
    val downloadsFlow: Flow<List<DownloadItemEntity>> = prodDao.getAllDownloadsFlow()

    suspend fun initOrRestoreDevice(): Boolean = withContext(Dispatchers.IO) {
        val existing = deviceDao.getDeviceDirect()
        val now = System.currentTimeMillis()
        if (existing == null) {
            // First time launch: Initialize defaults
            seedDefaults(now)
            true
        } else {
            // Subsequent start: Just update boot and read timestamp
            val deviceId = existing.id
            deviceDao.updateLastRead(now)
            // Ensure persistent browser profile is loaded and marked read
            val existingProfile = browserDao.getProfileDirect(deviceId) ?: browserDao.getAnyProfileDirect()
            if (existingProfile == null) {
                val profile = BrowserProfileEntity(
                    id = 1L,
                    deviceId = deviceId,
                    profileName = "Virtual User",
                    email = "user@virtualphone.net",
                    avatarColorHex = "#6366F1",
                    searchEngine = "NexusSearch",
                    cookiesEnabled = true,
                    isFirstRunDone = true,
                    lastActiveUrl = "https://nexus.search",
                    lastActiveTitle = "Nexus Search",
                    lastWriteTimestamp = now,
                    lastReadTimestamp = now
                )
                browserDao.insertProfile(profile)
            } else {
                if (existingProfile.deviceId != deviceId) {
                    browserDao.insertProfile(existingProfile.copy(deviceId = deviceId, lastReadTimestamp = now))
                } else {
                    browserDao.updateLastRead(now, deviceId)
                }
            }
            false
        }
    }

    private suspend fun seedDefaults(now: Long) {
        // 1. Device entity
        val device = VirtualDeviceEntity(
            id = "primary_device",
            modelName = "Pixel Virtual Pro 15",
            osVersion = "AVOS 15.2 (Native Compose)",
            firstLaunchDone = true,
            wallpaperId = 1,
            isDarkTheme = true,
            brightness = 0.85f,
            volumeLevel = 0.70f,
            isWifiOn = true,
            isBluetoothOn = true,
            isCellularOn = true,
            batteryLevel = 92,
            lastBootTime = now,
            lastWriteTime = now,
            lastReadTime = now
        )
        deviceDao.insertOrUpdate(device)

        // 2. Apps
        val defaultApps = listOf(
            VirtualAppEntity("com.virtual.phone", "Phone", "phone", "Communication", isDockApp = true, orderIndex = 1),
            VirtualAppEntity("com.virtual.messages", "Messages", "message", "Communication", isDockApp = true, orderIndex = 2),
            VirtualAppEntity("com.virtual.browser", "Chrome", "chrome", "Internet", isDockApp = true, orderIndex = 3),
            VirtualAppEntity("com.virtual.camera", "Camera", "camera", "Media", isDockApp = true, orderIndex = 4),
            VirtualAppEntity("com.virtual.gallery", "Gallery", "gallery", "Media", orderIndex = 5),
            VirtualAppEntity("com.virtual.calculator", "Calculator", "calculate", "Tools", orderIndex = 6),
            VirtualAppEntity("com.virtual.clock", "Clock", "clock", "Tools", orderIndex = 7),
            VirtualAppEntity("com.virtual.calendar", "Calendar", "calendar", "Productivity", orderIndex = 8),
            VirtualAppEntity("com.virtual.notes", "Notes", "notes", "Productivity", orderIndex = 9),
            VirtualAppEntity("com.virtual.files", "Files", "folder", "System", orderIndex = 10),
            VirtualAppEntity("com.virtual.music", "Music", "music", "Media", orderIndex = 11),
            VirtualAppEntity("com.virtual.downloads", "Downloads", "download", "Tools", orderIndex = 12),
            VirtualAppEntity("com.virtual.contacts", "Contacts", "contacts", "Communication", orderIndex = 13),
            VirtualAppEntity("com.virtual.settings", "Settings", "settings", "System", orderIndex = 14),
            VirtualAppEntity("com.virtual.debug", "Dev Debug", "bug", "System", orderIndex = 15)
        )
        appDao.insertApps(defaultApps)

        // 3. Browser defaults (Persisted directly in Room)
        val profile = BrowserProfileEntity(
            id = 1L,
            deviceId = "primary_device",
            profileName = "Virtual User",
            email = "user@virtualphone.net",
            avatarColorHex = "#6366F1",
            searchEngine = "NexusSearch",
            cookiesEnabled = true,
            isFirstRunDone = true,
            lastActiveUrl = "https://nexus.search",
            lastActiveTitle = "Nexus Search",
            lastWriteTimestamp = now,
            lastReadTimestamp = now
        )
        browserDao.insertProfile(profile)

        val bookmarks = listOf(
            BrowserBookmarkEntity(title = "Nexus Search", url = "https://nexus.search", createdTimestamp = now - 50000),
            BrowserBookmarkEntity(title = "SimMail Portal", url = "https://simmail.com", createdTimestamp = now - 40000),
            BrowserBookmarkEntity(title = "NexusFeed Social", url = "https://nexusfeed.com", createdTimestamp = now - 30000),
            BrowserBookmarkEntity(title = "Daily Global News", url = "https://dailynews.org", createdTimestamp = now - 20000),
            BrowserBookmarkEntity(title = "OmniPedia Wiki", url = "https://omnipedia.org", createdTimestamp = now - 10000)
        )
        bookmarks.forEach { browserDao.insertBookmark(it) }

        val historyItems = listOf(
            BrowserHistoryEntity(url = "https://nexus.search", title = "Nexus Search - Fast, Private, Simulated", visitedTimestamp = now - 90000),
            BrowserHistoryEntity(url = "https://simmail.com", title = "SimMail - Inbox (2 unread)", visitedTimestamp = now - 60000),
            BrowserHistoryEntity(url = "https://dailynews.org", title = "Daily Global News - Technology Trends 2026", visitedTimestamp = now - 30000)
        )
        historyItems.forEach { browserDao.insertHistory(it) }

        val initialTab = BrowserTabEntity(
            title = "Nexus Search",
            url = "https://nexus.search",
            isActive = true,
            createdTimestamp = now
        )
        browserDao.insertTab(initialTab)

        val simAccount = BrowserAccountEntity(
            siteDomain = "simmail.com",
            username = "user@virtualphone.net",
            displayName = "Alex Carter",
            authToken = "auth_tok_simmail_8923a",
            lastLoginTimestamp = now - 72000
        )
        browserDao.insertAccount(simAccount)

        // 4. Gallery defaults
        val galleryItems = listOf(
            GalleryItemEntity(title = "Sunrise Over Alpine Range", category = "Wallpapers", dateAdded = now - 3600000, colorSeedHex = "#F59E0B", imageTag = "landscape", isFavorite = true),
            GalleryItemEntity(title = "Cyber City Reflection", category = "Wallpapers", dateAdded = now - 7200000, colorSeedHex = "#8B5CF6", imageTag = "city", isFavorite = true),
            GalleryItemEntity(title = "Turquoise Coast Waves", category = "Camera", dateAdded = now - 1800000, colorSeedHex = "#06B6D4", imageTag = "ocean", isFavorite = false),
            GalleryItemEntity(title = "Golden Autumn Forest", category = "Camera", dateAdded = now - 900000, colorSeedHex = "#EA580C", imageTag = "nature", isFavorite = false),
            GalleryItemEntity(title = "Minimalist Architecture", category = "Downloads", dateAdded = now - 600000, colorSeedHex = "#64748B", imageTag = "architecture", isFavorite = false),
            GalleryItemEntity(title = "Abstract Neon Glow", category = "Wallpapers", dateAdded = now - 300000, colorSeedHex = "#EC4899", imageTag = "abstract", isFavorite = true)
        )
        galleryDao.insertItems(galleryItems)

        // 5. Contacts & Messages & Calls
        val contacts = listOf(
            ContactEntity(name = "Alex Rivera", phoneNumber = "+1 (555) 234-5678", email = "alex.rivera@techstudio.com", avatarColorHex = "#10B981"),
            ContactEntity(name = "Sarah Chen", phoneNumber = "+1 (555) 876-5432", email = "sarah.chen@innovate.org", avatarColorHex = "#3B82F6"),
            ContactEntity(name = "Mom", phoneNumber = "+1 (555) 432-1098", email = "mom@homefamily.net", avatarColorHex = "#EC4899"),
            ContactEntity(name = "David Miller", phoneNumber = "+1 (555) 901-2345", email = "david.m@designlabs.io", avatarColorHex = "#F59E0B"),
            ContactEntity(name = "Emma Watson", phoneNumber = "+1 (555) 345-6789", email = "emma.w@creatives.co", avatarColorHex = "#8B5CF6")
        )
        contacts.forEach { contact ->
            val contactId = commDao.insertContact(contact)
            when (contact.name) {
                "Alex Rivera" -> {
                    commDao.insertMessages(listOf(
                        MessageEntity(contactId = contactId, senderName = "Alex Rivera", text = "Hey! Have you tried the virtual OS?", timestamp = now - 3600000, isFromMe = false),
                        MessageEntity(contactId = contactId, senderName = "Me", text = "Yes, it runs completely natively inside Android with persistent Room DB!", timestamp = now - 3000000, isFromMe = true),
                        MessageEntity(contactId = contactId, senderName = "Alex Rivera", text = "That's awesome, browser history and photos stay intact!", timestamp = now - 2400000, isFromMe = false)
                    ))
                }
                "Sarah Chen" -> {
                    commDao.insertMessages(listOf(
                        MessageEntity(contactId = contactId, senderName = "Sarah Chen", text = "Design review meeting shifted to 3:30 PM today.", timestamp = now - 7200000, isFromMe = false),
                        MessageEntity(contactId = contactId, senderName = "Me", text = "Got it! Added it to the Calendar.", timestamp = now - 6800000, isFromMe = true)
                    ))
                }
                "Mom" -> {
                    commDao.insertMessages(listOf(
                        MessageEntity(contactId = contactId, senderName = "Mom", text = "Hope you're having a wonderful day! Call me when you get a chance.", timestamp = now - 1800000, isFromMe = false),
                        MessageEntity(contactId = contactId, senderName = "Me", text = "Will do Mom, love you!", timestamp = now - 1200000, isFromMe = true)
                    ))
                }
            }
        }

        val callLogs = listOf(
            CallLogEntity(number = "+1 (555) 432-1098", contactName = "Mom", type = "INCOMING", timestamp = now - 14400000, durationSeconds = 184),
            CallLogEntity(number = "+1 (555) 876-5432", contactName = "Sarah Chen", type = "OUTGOING", timestamp = now - 8200000, durationSeconds = 52),
            CallLogEntity(number = "+1 (555) 000-8899", contactName = "Unknown Caller", type = "MISSED", timestamp = now - 4100000, durationSeconds = 0)
        )
        commDao.insertCallLogs(callLogs)

        val notifications = listOf(
            VirtualNotificationEntity(appPackage = "com.virtual.settings", title = "Virtual OS 15 Active", content = "Virtual smartphone initialized with full Room database persistence.", timestamp = now - 60000, iconName = "smartphone"),
            VirtualNotificationEntity(appPackage = "com.virtual.messages", title = "New message from Alex", content = "That's awesome, browser history and photos stay intact!", timestamp = now - 2400000, iconName = "message"),
            VirtualNotificationEntity(appPackage = "com.virtual.calendar", title = "Upcoming: Coffee with Sarah", content = "Today at 3:30 PM at Artisan Roastery", timestamp = now - 120000, iconName = "calendar")
        )
        commDao.insertNotifications(notifications)

        // 6. Productivity defaults
        val notes = listOf(
            VirtualNoteEntity(
                title = "Welcome to VirtualPhone",
                content = "This is a complete simulated smartphone running natively in Jetpack Compose.\n\nAll your actions - browser history, open tabs, notes, gallery pictures, contacts, and settings - are saved in a local SQLite Room database and will NEVER reset when backgrounded or closed.",
                colorHex = "#FEF08A",
                updatedAt = now - 120000,
                isPinned = true
            ),
            VirtualNoteEntity(
                title = "Weekend Project Ideas",
                content = "- Try camera snapshot simulation\n- Add custom bookmarks in Chrome\n- Change virtual wallpaper in Settings\n- Run the Dev Persistence verification test",
                colorHex = "#BAE6FD",
                updatedAt = now - 60000,
                isPinned = false
            ),
            VirtualNoteEntity(
                title = "Shopping Checklist",
                content = "[x] Organic coffee beans\n[ ] Oat milk\n[ ] Sourdough bread\n[ ] Fresh avocados",
                colorHex = "#BBF7D0",
                updatedAt = now - 30000,
                isPinned = false
            )
        )
        prodDao.insertNotes(notes)

        val events = listOf(
            CalendarEventEntity(title = "Morning Standup", description = "Virtual OS Engineering sync", dateTimestamp = now, timeString = "09:30 AM", colorHex = "#3B82F6"),
            CalendarEventEntity(title = "Coffee with Sarah", description = "Discuss app interface improvements", dateTimestamp = now, timeString = "03:30 PM", colorHex = "#10B981"),
            CalendarEventEntity(title = "Evening Gym Workout", description = "Cardio and strength training", dateTimestamp = now, timeString = "06:30 PM", colorHex = "#F59E0B")
        )
        prodDao.insertEvents(events)

        val downloads = listOf(
            DownloadItemEntity(fileName = "virtual_device_specifications.pdf", fileSize = "2.4 MB", fileType = "PDF", downloadedTimestamp = now - 3600000, status = "COMPLETED"),
            DownloadItemEntity(fileName = "synthwave_sunset_theme.mp3", fileSize = "7.8 MB", fileType = "Audio", downloadedTimestamp = now - 1800000, status = "COMPLETED")
        )
        prodDao.insertDownloads(downloads)
    }

    // App Management & Recents
    suspend fun openApp(packageName: String, appName: String, iconName: String) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        appDao.insertRecentApp(RecentAppEntity(packageName, appName, iconName, now))
        deviceDao.updateLastRead(now)
    }

    suspend fun closeRecentApp(packageName: String) = withContext(Dispatchers.IO) {
        appDao.removeRecentApp(packageName)
    }

    suspend fun clearAllRecentApps() = withContext(Dispatchers.IO) {
        appDao.clearRecentApps()
    }

    // Device Settings
    suspend fun updateWallpaper(wallpaperId: Int) = withContext(Dispatchers.IO) {
        deviceDao.updateWallpaper(wallpaperId, System.currentTimeMillis())
    }

    suspend fun updateTheme(isDark: Boolean) = withContext(Dispatchers.IO) {
        deviceDao.updateTheme(isDark, System.currentTimeMillis())
    }

    suspend fun updateQuickSettings(wifi: Boolean, bluetooth: Boolean, brightness: Float, volume: Float) = withContext(Dispatchers.IO) {
        deviceDao.updateQuickSettings(wifi, bluetooth, brightness, volume, System.currentTimeMillis())
    }

    // Browser Operations
    suspend fun recordBrowserHistory(url: String, title: String) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        browserDao.insertHistory(BrowserHistoryEntity(url = url, title = title, visitedTimestamp = now))
        browserDao.updateLastActivePage(url, title, now)
        deviceDao.updateLastRead(now)
    }

    suspend fun completeChromeFirstRun(profileName: String, email: String): BrowserProfileEntity = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val deviceId = deviceDao.getDeviceDirect()?.id ?: "primary_device"
        val existing = browserDao.getProfileDirect(deviceId) ?: browserDao.getAnyProfileDirect()
        val updated = if (existing != null) {
            existing.copy(
                deviceId = deviceId,
                profileName = profileName,
                email = email,
                isFirstRunDone = true,
                lastWriteTimestamp = now
            )
        } else {
            BrowserProfileEntity(
                id = 1L,
                deviceId = deviceId,
                profileName = profileName,
                email = email,
                isFirstRunDone = true,
                lastWriteTimestamp = now,
                lastReadTimestamp = now
            )
        }
        browserDao.insertProfile(updated)
        if (browserDao.getTabsCount() == 0) {
            browserDao.insertTab(
                BrowserTabEntity(title = "Nexus Search", url = "https://nexus.search", isActive = true, createdTimestamp = now)
            )
        }
        deviceDao.updateLastRead(now)
        updated
    }

    suspend fun getBrowserProfileDirect(): BrowserProfileEntity? = withContext(Dispatchers.IO) {
        val deviceId = deviceDao.getDeviceDirect()?.id ?: "primary_device"
        browserDao.getProfileDirect(deviceId) ?: browserDao.getAnyProfileDirect()
    }

    suspend fun getBrowserProfileCount(): Int = withContext(Dispatchers.IO) { browserDao.getProfileCount() }

    suspend fun getBrowserTabsCount(): Int = withContext(Dispatchers.IO) { browserDao.getTabsCount() }
    suspend fun getBrowserBookmarksCount(): Int = withContext(Dispatchers.IO) { browserDao.getBookmarksCount() }
    suspend fun getBrowserHistoryCount(): Int = withContext(Dispatchers.IO) { browserDao.getHistoryCount() }
    suspend fun getBrowserAccountsCount(): Int = withContext(Dispatchers.IO) { browserDao.getAccountsCount() }

    suspend fun addBookmark(title: String, url: String) = withContext(Dispatchers.IO) {
        browserDao.insertBookmark(BrowserBookmarkEntity(title = title, url = url, createdTimestamp = System.currentTimeMillis()))
    }

    suspend fun removeBookmark(id: Long) = withContext(Dispatchers.IO) {
        browserDao.deleteBookmark(id)
    }

    suspend fun clearBrowserHistory() = withContext(Dispatchers.IO) {
        browserDao.clearHistory()
    }

    suspend fun addBrowserTab(title: String, url: String): Long = withContext(Dispatchers.IO) {
        browserDao.insertTab(BrowserTabEntity(title = title, url = url, isActive = true, createdTimestamp = System.currentTimeMillis()))
    }

    suspend fun closeBrowserTab(id: Long) = withContext(Dispatchers.IO) {
        browserDao.deleteTab(id)
    }

    suspend fun saveBrowserAccount(domain: String, username: String, displayName: String, token: String) = withContext(Dispatchers.IO) {
        browserDao.deleteAccountForDomain(domain)
        browserDao.insertAccount(
            BrowserAccountEntity(
                siteDomain = domain,
                username = username,
                displayName = displayName,
                authToken = token,
                lastLoginTimestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun removeBrowserAccount(domain: String) = withContext(Dispatchers.IO) {
        browserDao.deleteAccountForDomain(domain)
    }

    // Gallery Operations
    suspend fun addGalleryPhoto(title: String, category: String, colorSeed: String, imageTag: String): Long = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val id = galleryDao.insertItem(
            GalleryItemEntity(
                title = title,
                category = category,
                dateAdded = now,
                colorSeedHex = colorSeed,
                imageTag = imageTag,
                isFavorite = false
            )
        )
        // Add a notification for photo capture
        commDao.insertNotification(
            VirtualNotificationEntity(
                appPackage = "com.virtual.camera",
                title = "Photo Captured",
                content = "Saved $title to Gallery",
                timestamp = now,
                iconName = "camera"
            )
        )
        deviceDao.updateLastRead(now)
        id
    }

    suspend fun deleteGalleryItem(id: Long) = withContext(Dispatchers.IO) {
        galleryDao.deleteItem(id)
    }

    suspend fun toggleGalleryFavorite(id: Long, isFav: Boolean) = withContext(Dispatchers.IO) {
        galleryDao.toggleFavorite(id, isFav)
    }

    // Communication Operations
    suspend fun addContact(name: String, phone: String, email: String, colorHex: String): Long = withContext(Dispatchers.IO) {
        commDao.insertContact(ContactEntity(name = name, phoneNumber = phone, email = email, avatarColorHex = colorHex))
    }

    suspend fun deleteContact(id: Long) = withContext(Dispatchers.IO) {
        commDao.deleteContact(id)
        commDao.deleteMessagesForContact(id)
    }

    suspend fun sendMessage(contactId: Long, senderName: String, text: String, isFromMe: Boolean): Long = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val id = commDao.insertMessage(
            MessageEntity(contactId = contactId, senderName = senderName, text = text, timestamp = now, isFromMe = isFromMe, isRead = true)
        )
        deviceDao.updateLastRead(now)
        id
    }

    suspend fun logCall(number: String, name: String, type: String, duration: Int) = withContext(Dispatchers.IO) {
        commDao.insertCallLog(CallLogEntity(number = number, contactName = name, type = type, timestamp = System.currentTimeMillis(), durationSeconds = duration))
    }

    suspend fun dismissNotification(id: Long) = withContext(Dispatchers.IO) {
        commDao.dismissNotification(id)
    }

    suspend fun clearAllNotifications() = withContext(Dispatchers.IO) {
        commDao.clearNotifications()
    }

    // Productivity Operations
    suspend fun saveNote(id: Long, title: String, content: String, colorHex: String, isPinned: Boolean) = withContext(Dispatchers.IO) {
        if (id == 0L) {
            prodDao.insertNote(VirtualNoteEntity(title = title, content = content, colorHex = colorHex, updatedAt = System.currentTimeMillis(), isPinned = isPinned))
        } else {
            prodDao.updateNote(VirtualNoteEntity(id = id, title = title, content = content, colorHex = colorHex, updatedAt = System.currentTimeMillis(), isPinned = isPinned))
        }
    }

    suspend fun deleteNote(id: Long) = withContext(Dispatchers.IO) {
        prodDao.deleteNote(id)
    }

    suspend fun addCalendarEvent(title: String, desc: String, timestamp: Long, timeStr: String, color: String) = withContext(Dispatchers.IO) {
        prodDao.insertEvent(CalendarEventEntity(title = title, description = desc, dateTimestamp = timestamp, timeString = timeStr, colorHex = color))
    }

    suspend fun deleteCalendarEvent(id: Long) = withContext(Dispatchers.IO) {
        prodDao.deleteEvent(id)
    }

    suspend fun addDownload(fileName: String, fileSize: String, fileType: String) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        prodDao.insertDownload(DownloadItemEntity(fileName = fileName, fileSize = fileSize, fileType = fileType, downloadedTimestamp = now, status = "COMPLETED"))
        commDao.insertNotification(
            VirtualNotificationEntity(
                appPackage = "com.virtual.downloads",
                title = "Download Complete",
                content = "$fileName ($fileSize)",
                timestamp = now,
                iconName = "download"
            )
        )
    }

    // RESET VIRTUAL DEVICE (ONLY triggered by explicit user confirmation in Settings!)
    suspend fun resetVirtualDevice() = withContext(Dispatchers.IO) {
        deviceDao.clearDevice()
        appDao.clearAllApps()
        appDao.clearRecentApps()
        browserDao.clearHistory()
        browserDao.clearBookmarks()
        browserDao.clearTabs()
        browserDao.clearAccounts()
        galleryDao.clearGallery()
        commDao.clearContacts()
        commDao.clearMessages()
        commDao.clearCallLogs()
        commDao.clearNotifications()
        prodDao.clearNotes()
        prodDao.clearEvents()
        prodDao.clearDownloads()

        // Re-seed pristine defaults
        seedDefaults(System.currentTimeMillis())
    }

    // PERSISTENCE VERIFICATION TEST
    suspend fun runPersistenceTest(): PersistenceTestResult = withContext(Dispatchers.IO) {
        val testToken = "TEST_${System.currentTimeMillis()}"
        val testUrl = "https://persistence.test/$testToken"
        val testTitle = "Persistence Check $testToken"

        val t0 = System.currentTimeMillis()
        // 1. Write to database
        val insertedHistoryId = browserDao.insertHistory(
            BrowserHistoryEntity(url = testUrl, title = testTitle, visitedTimestamp = t0)
        )
        val insertedPhotoId = galleryDao.insertItem(
            GalleryItemEntity(title = "TestPhoto_$testToken", category = "Test", dateAdded = t0, colorSeedHex = "#10B981", imageTag = "test")
        )
        val insertedNoteId = prodDao.insertNote(
            VirtualNoteEntity(title = "TestNote_$testToken", content = "Verifying Room database persistence.", updatedAt = t0)
        )
        val writeDuration = System.currentTimeMillis() - t0

        // 2. Read directly from database
        val t1 = System.currentTimeMillis()
        val readHistoryCount = browserDao.getHistoryCount()
        val readGalleryCount = galleryDao.getGalleryCount()
        val readDevice = deviceDao.getDeviceDirect()
        val readAccountsCount = browserDao.getAccountsCount()
        val readContactsCount = commDao.getContactsCount()
        val readDuration = System.currentTimeMillis() - t1

        // Verify test record exists
        val verificationPassed = insertedHistoryId > 0 && insertedPhotoId > 0 && insertedNoteId > 0 && readDevice != null

        PersistenceTestResult(
            passed = verificationPassed,
            testToken = testToken,
            writeDurationMs = writeDuration,
            readDurationMs = readDuration,
            historyCount = readHistoryCount,
            galleryCount = readGalleryCount,
            accountsCount = readAccountsCount,
            contactsCount = readContactsCount,
            deviceId = readDevice?.id ?: "unknown",
            deviceModel = readDevice?.modelName ?: "unknown",
            timestamp = System.currentTimeMillis()
        )
    }

    // CHROME PERSISTENCE VERIFICATION TEST
    suspend fun testChromePersistence(): ChromePersistenceTestResult = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        val testToken = "CHROME_TEST_${System.currentTimeMillis()}"
        val testUrl = "https://nexus.search/test/$testToken"
        val testTitle = "Chrome Verification $testToken"

        // 1. Create or load profile
        var profile = browserDao.getProfileDirect()
        if (profile == null) {
            profile = BrowserProfileEntity(
                id = 1L,
                deviceId = "primary_device",
                profileName = "Virtual User",
                email = "user@virtualphone.net",
                isFirstRunDone = true,
                lastActiveUrl = testUrl,
                lastActiveTitle = testTitle,
                lastWriteTimestamp = t0,
                lastReadTimestamp = t0
            )
            browserDao.insertProfile(profile)
        }

        val initialHistoryCount = browserDao.getHistoryCount()

        // 2. Write a test history item
        browserDao.insertHistory(
            BrowserHistoryEntity(url = testUrl, title = testTitle, visitedTimestamp = t0)
        )
        browserDao.updateLastActivePage(testUrl, testTitle, t0)
        val writeDuration = System.currentTimeMillis() - t0

        // 3. Read it back from Room (simulating app close & reopen)
        val t1 = System.currentTimeMillis()
        val reloadedProfile = browserDao.getProfileDirect()
        val newHistoryCount = browserDao.getHistoryCount()
        val readDuration = System.currentTimeMillis() - t1

        val historyPersisted = newHistoryCount > initialHistoryCount && reloadedProfile?.lastActiveUrl == testUrl
        val passed = reloadedProfile != null && reloadedProfile.id == profile.id && historyPersisted

        ChromePersistenceTestResult(
            passed = passed,
            profileId = profile.id,
            deviceId = profile.deviceId,
            isFirstRunDone = reloadedProfile?.isFirstRunDone ?: false,
            testUrl = testUrl,
            testTitle = testTitle,
            historyCountBefore = initialHistoryCount,
            historyCountAfter = newHistoryCount,
            profileReloadedId = reloadedProfile?.id ?: -1L,
            historyRecordPersisted = historyPersisted,
            writeDurationMs = writeDuration,
            readDurationMs = readDuration,
            timestamp = System.currentTimeMillis()
        )
    }
}

data class ChromePersistenceTestResult(
    val passed: Boolean,
    val profileId: Long,
    val deviceId: String,
    val isFirstRunDone: Boolean,
    val testUrl: String,
    val testTitle: String,
    val historyCountBefore: Int,
    val historyCountAfter: Int,
    val profileReloadedId: Long,
    val historyRecordPersisted: Boolean,
    val writeDurationMs: Long,
    val readDurationMs: Long,
    val timestamp: Long
)

data class PersistenceTestResult(
    val passed: Boolean,
    val testToken: String,
    val writeDurationMs: Long,
    val readDurationMs: Long,
    val historyCount: Int,
    val galleryCount: Int,
    val accountsCount: Int,
    val contactsCount: Int,
    val deviceId: String,
    val deviceModel: String,
    val timestamp: Long
)
