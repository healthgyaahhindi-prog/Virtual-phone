package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "browser_profile")
data class BrowserProfileEntity(
    @PrimaryKey
    val id: Long = 1L,
    val deviceId: String = "primary_device",
    val profileName: String = "Virtual User",
    val email: String = "user@virtualphone.net",
    val avatarColorHex: String = "#6366F1",
    val searchEngine: String = "NexusSearch",
    val cookiesEnabled: Boolean = true,
    val isFirstRunDone: Boolean = true,
    val lastActiveUrl: String = "https://nexus.search",
    val lastActiveTitle: String = "Nexus Search",
    val lastWriteTimestamp: Long = System.currentTimeMillis(),
    val lastReadTimestamp: Long = System.currentTimeMillis()
) {
    val setupCompleted: Boolean get() = isFirstRunDone
}

@Entity(tableName = "browser_history")
data class BrowserHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val url: String,
    val title: String,
    val visitedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "browser_bookmarks")
data class BrowserBookmarkEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val url: String,
    val createdTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "browser_tabs")
data class BrowserTabEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val url: String,
    val isActive: Boolean = false,
    val createdTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "browser_accounts")
data class BrowserAccountEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val siteDomain: String,
    val username: String,
    val displayName: String,
    val authToken: String,
    val lastLoginTimestamp: Long = System.currentTimeMillis()
)
