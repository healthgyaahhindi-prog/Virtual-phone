package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "gallery_items")
data class GalleryItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val category: String, // "Camera", "Downloads", "Wallpapers", "Screenshots"
    val dateAdded: Long = System.currentTimeMillis(),
    val colorSeedHex: String = "#3B82F6",
    val imageTag: String = "landscape", // "camera_snap", "landscape", "sunset", "city", "nature", "abstract"
    val isFavorite: Boolean = false
)
