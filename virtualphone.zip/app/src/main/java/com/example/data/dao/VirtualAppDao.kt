package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.RecentAppEntity
import com.example.data.entity.VirtualAppEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VirtualAppDao {
    @Query("SELECT * FROM virtual_apps ORDER BY orderIndex ASC")
    fun getAllAppsFlow(): Flow<List<VirtualAppEntity>>

    @Query("SELECT * FROM virtual_apps WHERE isDockApp = 1 ORDER BY orderIndex ASC")
    fun getDockAppsFlow(): Flow<List<VirtualAppEntity>>

    @Query("SELECT * FROM virtual_apps")
    suspend fun getAllAppsDirect(): List<VirtualAppEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApps(apps: List<VirtualAppEntity>)

    @Query("SELECT * FROM recent_apps ORDER BY lastOpenedTime DESC")
    fun getRecentAppsFlow(): Flow<List<RecentAppEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentApp(recentApp: RecentAppEntity)

    @Query("DELETE FROM recent_apps WHERE packageName = :packageName")
    suspend fun removeRecentApp(packageName: String)

    @Query("DELETE FROM recent_apps")
    suspend fun clearRecentApps()

    @Query("DELETE FROM virtual_apps")
    suspend fun clearAllApps()
}
