package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.VirtualDeviceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VirtualDeviceDao {
    @Query("SELECT * FROM virtual_device WHERE id = 'primary_device' LIMIT 1")
    fun getDeviceFlow(): Flow<VirtualDeviceEntity?>

    @Query("SELECT * FROM virtual_device WHERE id = 'primary_device' LIMIT 1")
    suspend fun getDeviceDirect(): VirtualDeviceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(device: VirtualDeviceEntity)

    @Query("UPDATE virtual_device SET wallpaperId = :wallpaperId, lastWriteTime = :timestamp WHERE id = 'primary_device'")
    suspend fun updateWallpaper(wallpaperId: Int, timestamp: Long)

    @Query("UPDATE virtual_device SET isDarkTheme = :isDark, lastWriteTime = :timestamp WHERE id = 'primary_device'")
    suspend fun updateTheme(isDark: Boolean, timestamp: Long)

    @Query("UPDATE virtual_device SET isWifiOn = :wifi, isBluetoothOn = :bluetooth, brightness = :brightness, volumeLevel = :volume, lastWriteTime = :timestamp WHERE id = 'primary_device'")
    suspend fun updateQuickSettings(wifi: Boolean, bluetooth: Boolean, brightness: Float, volume: Float, timestamp: Long)

    @Query("UPDATE virtual_device SET lastReadTime = :timestamp WHERE id = 'primary_device'")
    suspend fun updateLastRead(timestamp: Long)

    @Query("DELETE FROM virtual_device")
    suspend fun clearDevice()
}
